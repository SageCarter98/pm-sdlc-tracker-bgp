---
name: kad-backend-api
description: "Use for server-side business logic, HTTP APIs, service integrations, authentication flows, and background jobs."
---

# Backend and API

## Purpose and inputs

Apply this workflow to the requested task without expanding its scope. Use API consumers, business invariants, identities and roles, data model, integration behavior, and current service conventions.

## Workflow

1. Inspect consumers, current contracts, identities, business invariants and service conventions.
2. Specify validation, response shapes, error semantics, pagination and compatibility only where relevant to the endpoint.
3. Implement server-side authentication and operation/object-level authorization; derive trusted business values on the server.
4. Define atomic writes and durable idempotency for retryable effects. Bound upstream timeouts, retries and job execution.
5. Exercise success and meaningful failure paths, including cross-user access and repeated or concurrent requests when they affect invariants.
6. Verify persistence and external-side-effect handling; document contract changes and operational limits.

## Decision rules and boundaries

Do not trust client-supplied roles, ownership, prices, or completion states. Retry only operations whose semantics permit it; use backoff and limits. Avoid leaking internal errors or sensitive fields. Distinguish authentication failures from denied access without unnecessarily exposing object existence.

## Tools and evidence

Select and read this skill before specialist execution; apply its relevant steps rather than merely naming it. Inspect actual project commands and installed versions before choosing tools. Use official references for uncertain or version-sensitive technical claims. Load only supporting skills justified by the task; reselect when scope crosses a new boundary.

For substantial work, tie acceptance criteria to changed artifacts and actual check results. Distinguish selected, loaded, applied and verified: reading proves only loading. Keep a brief record of applied skills, meaningful commands/results, limitations and justified deviations; a concise final summary suffices for a small task. Do not run ritual tests or weaken required checks to claim success. If tools or access are unavailable, finish useful authorized work, mark dependent verification blocked or unverified, and state the next concrete check. Never invent evidence or treat Markdown as tool-level enforcement.

## Quality checks

Test success, malformed input, unauthenticated access, cross-user access, repeated requests, concurrent writes, upstream failure, and rollback of partial work.

## Deliverable

Endpoint/job implementation, contract examples, authorization and failure evidence, idempotency scope and integration limits.

## Example

“Add monthly reports.” Define timezone and period boundaries, prevent duplicate sends, record job results, and keep recipient authorization explicit.

## Skill coordination

Use kad-database-engineering for transactions and constraints, kad-security-engineering for identity/access changes, and kad-testing-quality for boundary verification.

## Completion rule

Report completion only for acceptance criteria supported by evidence. Mark partial, blocked or unverified work explicitly. Explain material deviations and their effects; use expert judgment within the user’s scope and host rules. Reuse existing authorization; this skill grants no new permissions.
