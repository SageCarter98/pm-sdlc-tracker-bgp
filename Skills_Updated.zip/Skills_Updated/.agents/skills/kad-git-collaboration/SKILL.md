---
name: kad-git-collaboration
description: "Use for branches, commits, conflict resolution, pull request preparation, and safe repository collaboration."
---

# Git Collaboration

## Purpose and inputs

Apply this workflow to the requested task without expanding its scope. Use repository status, current branch, target branch, remotes, user edits, and requested collaboration action.

## Workflow

1. Inspect repository identity, current branch, target branch, remotes, working changes and the authorized action.
2. Preserve unrelated user work; isolate task changes when needed and stage named paths only.
3. Resolve conflicts by reading both intentions and testing their interaction; do not select one side blindly.
4. Inspect the final diff, conflict markers, accidental secrets and generated clutter; run checks relevant to changed behaviour.
5. Perform authorized commits or remote actions only in the intended repository/branch and report the exact resulting state.

## Decision rules and boundaries

Never discard unrelated user changes or rewrite shared history without explicit authorization. Stage named paths rather than all changes indiscriminately. Confirm repository and branch before pushing. Creating a local patch does not imply permission to merge or publish.

## Tools and evidence

Select and read this skill before specialist execution; apply its relevant steps rather than merely naming it. Inspect actual project commands and installed versions before choosing tools. Use official references for uncertain or version-sensitive technical claims. Load only supporting skills justified by the task; reselect when scope crosses a new boundary.

For substantial work, tie acceptance criteria to changed artifacts and actual check results. Distinguish selected, loaded, applied and verified: reading proves only loading. Keep a brief record of applied skills, meaningful commands/results, limitations and justified deviations; a concise final summary suffices for a small task. Do not run ritual tests or weaken required checks to claim success. If tools or access are unavailable, finish useful authorized work, mark dependent verification blocked or unverified, and state the next concrete check. Never invent evidence or treat Markdown as tool-level enforcement.

## Quality checks

Check for conflict markers, secrets, generated clutter, unintended files, and changed behavior after conflict resolution. Report exactly whether work is local, committed, pushed, or merged.

## Deliverable

Task-scoped diff and actual local/committed/pushed/merged status, verification, and unresolved conflicts or checks.

## Example

“Fix this merge conflict.” Preserve both intended behaviors, test their interaction, and explain any design choice required to resolve them.

## Skill coordination

Use kad-debugging for failing checks, kad-code-review for patch assessment and the affected domain skill for semantic conflicts.

## Completion rule

Report completion only for acceptance criteria supported by evidence. Mark partial, blocked or unverified work explicitly. Explain material deviations and their effects; use expert judgment within the user’s scope and host rules. Reuse existing authorization; this skill grants no new permissions.
