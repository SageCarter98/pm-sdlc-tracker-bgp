---
name: kad-debugging
description: "Use to investigate defects, runtime errors, failed builds, or unexpected system behavior."
---

# Debugging

## Purpose and inputs

Apply this workflow to the requested task without expanding its scope. Use expected versus actual behavior, reproduction steps, environment and version, logs without secrets, and recent changes.

## Workflow

1. Capture expected versus actual behaviour, revision, environment and the smallest reproduction.
2. Inspect logs and execution at the first boundary where observed behaviour diverges.
3. Rank plausible causes and run checks that distinguish them; change one relevant variable at a time.
4. Implement a focused correction to the responsible cause while preserving unrelated behaviour.
5. Rerun the original failing case and nearby risk-relevant paths; add a regression test where it protects meaningful reusable behaviour.
6. Remove temporary instrumentation; separate verified cause and resolution from inference if reproduction remains unavailable.

## Decision rules and boundaries

Avoid random reinstalling, broad rewrites, or suppressing errors without understanding them. If reproduction is unavailable, state the evidence gap and separate probable cause from verified cause. Limit retries and stop repeating an action that cannot yield new evidence.

## Tools and evidence

Select and read this skill before specialist execution; apply its relevant steps rather than merely naming it. Inspect actual project commands and installed versions before choosing tools. Use official references for uncertain or version-sensitive technical claims. Load only supporting skills justified by the task; reselect when scope crosses a new boundary.

For substantial work, tie acceptance criteria to changed artifacts and actual check results. Distinguish selected, loaded, applied and verified: reading proves only loading. Keep a brief record of applied skills, meaningful commands/results, limitations and justified deviations; a concise final summary suffices for a small task. Do not run ritual tests or weaken required checks to claim success. If tools or access are unavailable, finish useful authorized work, mark dependent verification blocked or unverified, and state the next concrete check. Never invent evidence or treat Markdown as tool-level enforcement.

## Quality checks

Verify the original symptom is resolved in the stated environment. Ensure the fix does not expose secrets, bypass permissions, or hide other failures. Add a regression test for a meaningful reusable defect.

## Deliverable

Reproduction, cause evidence, focused diff, original-case outcome and remaining uncertainty.

## Example

“Failed to fetch.” Check URL, server availability, network response, TLS and CORS separately; do not assume every fetch failure is CORS.

## Skill coordination

Load the affected domain skill after locating the boundary, and kad-testing-quality when designing regression evidence. Use kad-devops-delivery for pipeline/environment faults.

## Completion rule

Report completion only for acceptance criteria supported by evidence. Mark partial, blocked or unverified work explicitly. Explain material deviations and their effects; use expert judgment within the user’s scope and host rules. Reuse existing authorization; this skill grants no new permissions.
