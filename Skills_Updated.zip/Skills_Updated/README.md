# Skills Updated

KenAddme Expert Agent Pack — version 1.1.0

Contains all 20 revised engineering skills, matching AGENTS.md and AGENT.md entrypoints, a routing catalogue, installation/context helpers, frontend visual-quality guidance and verification records.

Start with IMPLEMENTATION.md. Preview installation before applying it. Merge existing project instructions deliberately; the installer refuses conflicting files. The archive is portable and does not install itself into an external agent.

The revised skills require relevant skill loading, practical application, proportionate evidence and honest completion status. Frontend work now includes visual direction, reusable design values, representative journeys and rendered inspection. Markdown is guidance; host code must enforce permissions and any completion gates.

Read VALIDATION_REPORT.md for actual checks and limitations. APPROVAL.md records the authorization scope. SHA256SUMS.json detects changed package files; it is not a signature.
