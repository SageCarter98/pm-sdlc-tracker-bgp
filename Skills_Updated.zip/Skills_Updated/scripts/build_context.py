"""Assemble trusted context for a custom host; does not call a model or tools."""
import argparse
import hashlib
import json
import sys
from validate_pack import ROOT, validate

def build_context(names, request):
    validate()
    catalogue = json.loads((ROOT / 'skills-index.json').read_text(encoding='utf-8'))['skills']
    allowed = {s['name']: s for s in catalogue}
    unique = list(dict.fromkeys(names))
    unknown = [name for name in unique if name not in allowed]
    if unknown:
        raise ValueError('Unknown skill selection: ' + ', '.join(unknown))
    bodies = [(ROOT / allowed[name]['path']).read_text(encoding='utf-8') for name in unique]
    instructions = (ROOT / 'AGENTS.md').read_text(encoding='utf-8')
    if bodies:
        instructions += '\n\n# Selected skills\n\n' + '\n\n'.join(bodies)
    return {
        'pack_version': '1.1.0',
        'trusted_instructions': instructions,
        'skill_catalogue': [{'name': s['name'], 'description': s['description']} for s in catalogue],
        'selected_skills': unique,
        'loaded_skills': [{'name': name, 'sha256': hashlib.sha256((ROOT / allowed[name]['path']).read_bytes()).hexdigest(), 'status': 'loaded'} for name in unique],
        'user_request': request,
    }

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--skills', nargs='*', default=[])
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument('--request')
    group.add_argument('--request-stdin', action='store_true', help='Read request from standard input')
    args = parser.parse_args()
    try:
        request = sys.stdin.read() if args.request_stdin else args.request
        print(json.dumps(build_context(args.skills, request), indent=2, ensure_ascii=False))
    except (ValueError, OSError, KeyError) as exc:
        print('Context assembly failed: ' + str(exc), file=sys.stderr)
        sys.exit(1)
