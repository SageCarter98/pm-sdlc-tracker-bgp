# Frontend visual quality workflow

Read this reference for new interfaces, substantial redesigns or visual defects. Apply only relevant checks for a small change. Keep creative freedom within product requirements and existing conventions.

## Establish a direction

Write a brief design intent: audience, primary task, tone, information density, existing brand constraints and the intended visual hierarchy. Select a coherent direction based on product needs. Reuse a sound existing design system; avoid imposing a fashionable generic dashboard on every product.

For a school accounts screen, prioritise fast student identification, a clearly labelled amount, obvious payment status, and readable records. For a public portfolio, prioritise work samples, strong typography and an understandable contact journey. These examples guide decisions; they are not mandatory templates.

Define reusable values for type scale, line height, colour roles, spacing, content widths, borders, radii and elevation where used. Make interactive states consistent. Use a restrained set of emphasis levels and one clear primary action per relevant task region. Prefer existing licensed assets and icon conventions; do not invent a new icon system without need.

## Build the representative journey

Choose a screen containing the product's important patterns. Use realistic labels, long names, empty lists and large values. Complete its happy path and relevant failure states, inspect it, then extend its components. Keep navigation predictable, forms grouped by user intent, tables comparable, and charts labelled with units and meaningful text alternatives.

For a fee form, demonstrate student selection, invalid amount feedback, pending submission, recoverable failure and confirmation. Do not pretend a disabled button or a mock receipt proves persistence or server-side duplicate prevention.

## Inspect actual rendering

Use supported browser or rendering tools. Choose widths appropriate to the audience; 390, 768 and 1440 CSS pixels are example starting points, not universal requirements. Check narrow layouts, long content, zoom, keyboard focus and reduced-motion behaviour where motion exists. Inspect primary, empty and error states as relevant.

Check hierarchy, alignment, spacing rhythm, readable text, visible controls, contrast, touch usability and overflow. Verify that sticky headers, dialogs and popovers do not hide actions or keyboard focus. Preserve form values after recoverable errors. Test navigation and submission separately from static screenshots.

Record viewport, state and what was actually inspected. Correct defects that obscure information, block an action, confuse navigation or disrupt visual consistency, and recheck the affected states. If the browser is unavailable, review code and state assumptions but mark visual inspection unverified.

## Evaluate without hiding critical defects

Assess hierarchy, consistency, readability, responsiveness and product fit separately. Suggested rubric: 1 unusable; 2 major rework; 3 functional with obvious defects; 4 ready with minor polish; 5 thoroughly refined for the agreed scope. These are review judgments, not objective measurements. Use evidence and reviewer identity/role when available; never fabricate a user review.

Target at least 4 in each dimension for a substantial frontend deliverable where this rubric is adopted. A critical functional, accessibility or authorization defect blocks full acceptance regardless of visual scores. A successful build, a screenshot, or an automated accessibility scan alone is insufficient proof of the whole journey.

## Evidence to retain

Record the visual direction and reusable values, relevant states, viewport checks, actual interaction results, integration status, defects corrected and remaining limitations. Keep the record concise and free of personal data. Report aesthetics separately from functional and security verification.
