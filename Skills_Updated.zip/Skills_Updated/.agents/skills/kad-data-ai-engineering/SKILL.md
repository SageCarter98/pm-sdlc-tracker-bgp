---
name: kad-data-ai-engineering
description: "Use for data pipelines, analytics, machine learning, retrieval systems, AI agents, and model evaluation."
---

# Data and AI Engineering

## Purpose and inputs

Apply this workflow to the requested task without expanding its scope. Use decision or task objective, data source rights, provenance, labels, expected users, privacy constraints, and evaluation criteria.

## Workflow

1. Define the task objective, data rights, privacy boundaries and evaluation criteria.
2. Inspect provenance, missingness, duplicates, leakage and relevant user slices; establish a simple baseline.
3. Separate evaluation data by the real deployment boundary and version data/configuration; keep held-out answers out of development context.
4. For agents, separate trusted instructions, skill catalogue/loading, retrieved evidence, memory, tool execution and host permissions.
5. Implement access filtering and bounded execution; record selected/loaded/applied/verified states only to the extent observable, without treating self-report as enforcement.
6. Evaluate representative and adversarial cases for quality, grounding, privacy, failures, latency and cost; retain rollback and monitoring plans.

## Decision rules and boundaries

Use prompts and skills for procedural guidance; describe fine-tuning as a separate model-training activity. Apply access filters before retrieval and avoid cross-user memory leakage. Never give a model unrestricted tools because its prompt says to be safe. Keep untrusted document content out of privileged instructions. Require abstention or escalation when evidence is insufficient.

## Tools and evidence

Select and read this skill before specialist execution; apply its relevant steps rather than merely naming it. Inspect actual project commands and installed versions before choosing tools. Use official references for uncertain or version-sensitive technical claims. Load only supporting skills justified by the task; reselect when scope crosses a new boundary.

For substantial work, tie acceptance criteria to changed artifacts and actual check results. Distinguish selected, loaded, applied and verified: reading proves only loading. Keep a brief record of applied skills, meaningful commands/results, limitations and justified deviations; a concise final summary suffices for a small task. Do not run ritual tests or weaken required checks to claim success. If tools or access are unavailable, finish useful authorized work, mark dependent verification blocked or unverified, and state the next concrete check. Never invent evidence or treat Markdown as tool-level enforcement.

## Quality checks

Check held-out results, relevant user slices, retrieval permissions, prompt-injection resistance, tool boundaries, and regression cases. Report actual measurements rather than claiming expert capability from a skill file.

## Deliverable

Pipeline or agent implementation, provenance and version notes, measured evaluation, tool-boundary evidence and explicit host capability limits.

## Example

“Build an agent from these policies.” Load trusted instructions, retrieve permitted evidence, enforce tool access in code, and evaluate realistic tasks before wider rollout.

## Skill coordination

Use kad-security-engineering for retrieval/tool controls, kad-testing-quality for held-out evaluations, and domain skills for integrations.

## Completion rule

Report completion only for acceptance criteria supported by evidence. Mark partial, blocked or unverified work explicitly. Explain material deviations and their effects; use expert judgment within the user’s scope and host rules. Reuse existing authorization; this skill grants no new permissions.
