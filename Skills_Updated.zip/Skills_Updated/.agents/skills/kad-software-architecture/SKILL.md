---
name: kad-software-architecture
description: "Use for software design, architecture, major structural changes, component boundaries, interface contracts and justified design patterns. For a small local refactor use kad-programming."
---

# Software Architecture

## Purpose and inputs

Apply this workflow to the requested task without expanding its scope. Use validated requirements, system constraints, expected scale, data sensitivity, team capability, and current architecture.

## Workflow

1. Read validated requirements, constraints and current component boundaries.
2. Trace data ownership, trust boundaries, core requests and failure paths; identify cohesion, coupling and interface obligations.
3. Compare the simplest viable design with credible alternatives against scale, maintenance, consistency and operational needs.
4. Specify components, contracts, state transitions, error semantics and migration steps; use design patterns only to solve an identified problem.
5. Record the decision, alternatives, consequences and reversal cost; walk through one normal request and one dependency failure.

## Decision rules and boundaries

Prefer a modular monolith when independent scaling or team boundaries do not justify distributed services. Choose technology from compatibility and operational needs, not popularity. Keep a single authoritative owner for critical data and avoid undocumented dual writes.

## Tools and evidence

Select and read this skill before specialist execution; apply its relevant steps rather than merely naming it. Inspect actual project commands and installed versions before choosing tools. Use official references for uncertain or version-sensitive technical claims. Load only supporting skills justified by the task; reselect when scope crosses a new boundary.

For substantial work, tie acceptance criteria to changed artifacts and actual check results. Distinguish selected, loaded, applied and verified: reading proves only loading. Keep a brief record of applied skills, meaningful commands/results, limitations and justified deviations; a concise final summary suffices for a small task. Do not run ritual tests or weaken required checks to claim success. If tools or access are unavailable, finish useful authorized work, mark dependent verification blocked or unverified, and state the next concrete check. Never invent evidence or treat Markdown as tool-level enforcement.

## Quality checks

Trace a core request and a dependency failure across the design. Verify that permissions, observability, recovery, and deployment are feasible. Challenge any component with no requirement or operational justification.

## Deliverable

Design and decision record linked to requirements, implementable interfaces, migration sequence and known trade-offs.

## Example

“Split everything into microservices.” Assess why separation is needed, explain costs, and propose only boundaries supported by requirements.

## Skill coordination

Use kad-requirements-analysis for unresolved outcomes; load database, backend, frontend or security skills at the corresponding boundaries. Use kad-programming for local refactoring.

## Completion rule

Report completion only for acceptance criteria supported by evidence. Mark partial, blocked or unverified work explicitly. Explain material deviations and their effects; use expert judgment within the user’s scope and host rules. Reuse existing authorization; this skill grants no new permissions.
