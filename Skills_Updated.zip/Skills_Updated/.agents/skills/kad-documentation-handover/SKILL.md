---
name: kad-documentation-handover
description: "Use for implementation guides, technical explanations, runbooks, user manuals, and maintainable handover documentation."
---

# Documentation and Handover

## Purpose and inputs

Apply this workflow to the requested task without expanding its scope. Use audience, verified system behavior, current code and configuration, operational responsibilities, and requested artifact format.

## Workflow

1. Identify audience, requested format and verified source behaviour.
2. Separate end-user tasks, developer setup and operator recovery; structure procedures around outcomes and prerequisites.
3. Write precise steps and realistic examples using actual paths, commands and interface labels; keep secrets out.
4. Explain important decisions and known limits using familiar words; retain exact names, values and authority scope.
5. Walk through a critical procedure where tools permit, inspect links and formatting, and identify unexecuted steps.
6. Deliver the requested artifact with maintenance ownership only when supplied.

## Decision rules and boundaries

Use simple natural vocabulary while retaining precise meaning. Do not invent screenshots, approvals, citations, test results, or owners. Keep organization frameworks distinct from project artifacts. Mark unfinished setup fields plainly rather than fabricating values.

## Tools and evidence

Select and read this skill before specialist execution; apply its relevant steps rather than merely naming it. Inspect actual project commands and installed versions before choosing tools. Use official references for uncertain or version-sensitive technical claims. Load only supporting skills justified by the task; reselect when scope crosses a new boundary.

For substantial work, tie acceptance criteria to changed artifacts and actual check results. Distinguish selected, loaded, applied and verified: reading proves only loading. Keep a brief record of applied skills, meaningful commands/results, limitations and justified deviations; a concise final summary suffices for a small task. Do not run ritual tests or weaken required checks to claim success. If tools or access are unavailable, finish useful authorized work, mark dependent verification blocked or unverified, and state the next concrete check. Never invent evidence or treat Markdown as tool-level enforcement.

## Quality checks

Walk through a critical setup or recovery procedure in an available test environment. Check internal links, examples, filenames, and alignment with actual behavior. Disclose steps not executed.

## Deliverable

Usable documentation, source/version scope, checked procedures and explicitly untested instructions.

## Example

“Write the clerk’s manual.” Explain adding a student, recording fees, correcting an error, and producing receipts using the application’s actual screens.

## Skill coordination

Use kad-human-communication for substantial prose, domain skills for technical accuracy and the relevant document-format skill for rendered artifacts.

## Completion rule

Report completion only for acceptance criteria supported by evidence. Mark partial, blocked or unverified work explicitly. Explain material deviations and their effects; use expert judgment within the user’s scope and host rules. Reuse existing authorization; this skill grants no new permissions.
