# Installation and integration

## Existing supported agent

Extract this archive and open a terminal in its top-level folder. The bundled helpers require Python 3.10 or newer and use its standard library.

Run `python scripts/validate_pack.py`, then `python scripts/test_helpers.py`.
Preview a project installation with `python scripts/install.py --target /absolute/path/to/project`. After inspecting the target, add `--apply` to copy the files. On Windows pass the quoted project path, for example `python scripts/install.py --target "C:\Projects\SchoolApp"`.

The installer checks hashes and conflicts before writing. It does not overwrite different existing files, including earlier pack versions. For an existing installation, merge AGENTS.md deliberately, preserve project-specific instructions, and replace only the identified old skill folders after backing them up. Keep one active copy of each skill. Do not delete the entire .agents directory. Repeat validation on the extracted release before copying and verify host discovery afterward.

The package layout uses .agents/skills. Confirm that your host supports that location; for hosts with an import interface, use their supported skill import workflow instead. AGENTS.md is the main shared template and AGENT.md is its compatibility copy. Configure the host to load one. A ZIP attachment or filesystem copy alone does not prove discovery.

Ask the host to list available skills without changing code, then exercise a bounded representative task. Inspect both skill selection and actual results. Use EVALUATION.md for broader qualification.

## Custom agent integration

Use `python scripts/build_context.py --skills kad-frontend-engineering --request "Improve the fee entry screen"` for context assembly. The helper validates the package, rejects unknown skill names, deduplicates selections and returns the catalogue, selected bodies, loaded content hashes and a separate user request.

The loaded records mean only that the helper read those bytes. They do not prove model attention, application or successful verification. No model client, autonomous router, tool executor or completion gate is implemented by this adapter.

Load shared instructions and selected skill bodies from a reviewed application-controlled location. Expose the catalogue first and select by task intent. Support safe reading of linked skill resources, including the frontend reference. Keep untrusted user input, retrieved material and tool results separate from privileged instructions. Preserve source trust during memory summaries.

Enforce identity, resource scope, input schemas, budgets and approvals in host code for every tool action. Loading a skill cannot grant access. If completion controls are implemented, check objective evidence for required criteria and allow explicit partial/blocked status. A model-authored checkbox is not independent verification.

For substantial work record task/criteria, skill content versions, changed artifacts, actual checks/results, justified deviations and limits. Use EVIDENCE_TEMPLATE.md as a concise starting point, not a mandatory form for trivial changes. Exclude secrets and unnecessary personal data.

## Updates and recovery

Version the reviewed release and retain the prior copy. Use the current baseline and a separate held-out evaluation set. Recheck changed skill behaviour and critical regression cases. Restore a previous version if a change causes regression, preserving unrelated project work. Institutional and project-specific governance remain separate from this portable pack.

After intentional package edits, review and test them before regenerating the checksum manifest for a new release. Do not rewrite hashes to conceal unexpected changes. Hashes detect accidental alteration, not an attacker who can replace the whole package.
