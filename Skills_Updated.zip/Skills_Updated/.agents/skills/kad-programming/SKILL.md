---
name: kad-programming
description: "Use to implement application logic, algorithms, command-line tools and behaviour-preserving refactors in an existing stack. Pair with frontend, backend or database skills for specialist work."
---

# Programming

## Purpose and inputs

Apply this workflow to the requested task without expanding its scope. Use task acceptance conditions, affected source, language and dependency versions, repository conventions, and test entry points.

## Workflow

1. Inspect affected code, callers, dependencies, commands and existing conventions.
2. Identify input contracts, invariants, boundary cases and expected scale; choose suitable data structures and a simple cohesive design.
3. Implement complete task-scoped behaviour with clear names, explicit errors and controlled side effects; preserve compatibility unless change is authorized.
4. For refactoring, establish observable behaviour first, make small structural changes, and check equivalent outputs and side effects. Avoid unrelated rewrites.
5. Run the smallest meaningful behaviour checks and required project gates; inspect the final diff and remove temporary diagnostics.

## Decision rules and boundaries

Do not add dependencies for trivial operations or rewrite unrelated code. Choose data structures from expected input size and operations; explain complexity when it affects the decision. Handle money with an exact representation and dates with explicit timezone rules. Keep secrets outside source.

## Tools and evidence

Select and read this skill before specialist execution; apply its relevant steps rather than merely naming it. Inspect actual project commands and installed versions before choosing tools. Use official references for uncertain or version-sensitive technical claims. Load only supporting skills justified by the task; reselect when scope crosses a new boundary.

For substantial work, tie acceptance criteria to changed artifacts and actual check results. Distinguish selected, loaded, applied and verified: reading proves only loading. Keep a brief record of applied skills, meaningful commands/results, limitations and justified deviations; a concise final summary suffices for a small task. Do not run ritual tests or weaken required checks to claim success. If tools or access are unavailable, finish useful authorized work, mark dependent verification blocked or unverified, and state the next concrete check. Never invent evidence or treat Markdown as tool-level enforcement.

## Quality checks

Run focused behavior tests and relevant static checks. Cover boundary inputs, errors, and changed invariants. Inspect the diff for accidental edits and temporary diagnostics. Do not invent commands that the repository does not define.

## Deliverable

Changed behaviour and files, relevant command outcomes, invariant checks and outstanding execution limits.

## Example

“Prevent duplicate fee payments.” Enforce uniqueness or idempotency in persistent storage and test repeated or concurrent submission.

## Skill coordination

Use kad-debugging for uncertain failures, kad-software-architecture for structural design, and the relevant frontend/backend/database skill when implementation crosses those boundaries.

## Completion rule

Report completion only for acceptance criteria supported by evidence. Mark partial, blocked or unverified work explicitly. Explain material deviations and their effects; use expert judgment within the user’s scope and host rules. Reuse existing authorization; this skill grants no new permissions.
