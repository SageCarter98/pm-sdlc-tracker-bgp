---
name: kad-requirements-analysis
description: "Use to turn an idea or change request into testable product requirements and acceptance criteria."
---

# Requirements Analysis

## Purpose and inputs

Apply this workflow to the requested task without expanding its scope. Use problem, users and roles, existing workflow, business rules, constraints, and available project baseline.

## Workflow

1. Inspect the supplied baseline and identify users, roles, intended outcomes and current pain.
2. Map the primary journey and meaningful alternatives: denied access, invalid input, empty data, duplicate requests and recovery.
3. Separate business rules, functional behaviour and measurable quality targets; record assumptions and unresolved contradictions.
4. Give substantial requirements stable IDs and observable acceptance conditions. Include visual fit and responsive interaction for UI work without dictating an unnecessary stack.
5. Review scope and dependencies; resolve only essential unknowns with the user and proceed on reversible minor assumptions.

## Decision rules and boundaries

Resolve contradictory business rules before implementing affected behavior. Do not invent owners, legal duties, deadlines, or performance targets. Offer a measurable proposed target for confirmation where none exists. Preserve an accepted baseline and record changes instead of silently expanding it.

## Tools and evidence

Select and read this skill before specialist execution; apply its relevant steps rather than merely naming it. Inspect actual project commands and installed versions before choosing tools. Use official references for uncertain or version-sensitive technical claims. Load only supporting skills justified by the task; reselect when scope crosses a new boundary.

For substantial work, tie acceptance criteria to changed artifacts and actual check results. Distinguish selected, loaded, applied and verified: reading proves only loading. Keep a brief record of applied skills, meaningful commands/results, limitations and justified deviations; a concise final summary suffices for a small task. Do not run ritual tests or weaken required checks to claim success. If tools or access are unavailable, finish useful authorized work, mark dependent verification blocked or unverified, and state the next concrete check. Never invent evidence or treat Markdown as tool-level enforcement.

## Quality checks

Check every role and critical journey, including denied access, empty data, errors, duplicate submissions, and recovery. Ensure requirements describe outcomes without prematurely fixing the implementation.

## Deliverable

Requirement-to-acceptance mapping, assumptions, decisions and excluded scope; distinguish proposed targets from agreed requirements.

## Example

“A clerk records school fees.” Specify partial payments, duplicate receipt handling, student identity, authorized corrections, and administrator visibility.

## Skill coordination

Use kad-frontend-engineering for interface acceptance, kad-security-engineering for access requirements, and kad-delivery-change-management for scope changes.

## Completion rule

Report completion only for acceptance criteria supported by evidence. Mark partial, blocked or unverified work explicitly. Explain material deviations and their effects; use expert judgment within the user’s scope and host rules. Reuse existing authorization; this skill grants no new permissions.
