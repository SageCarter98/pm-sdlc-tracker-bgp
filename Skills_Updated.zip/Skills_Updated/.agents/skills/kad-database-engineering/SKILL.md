---
name: kad-database-engineering
description: "Use for relational or document schemas, queries, indexes, migrations, transactions, and data integrity."
---

# Database Engineering

## Purpose and inputs

Apply this workflow to the requested task without expanding its scope. Use entities, relationships, invariants, access patterns, current data, volume, database engine version, and recovery constraints.

## Workflow

1. Inspect actual engine/version, current schema, representative data, ownership and query patterns.
2. Model keys, relationships, uniqueness, null handling, lifecycle and transactional invariants.
3. Choose indexes from observed queries and inspect representative plans; record volume and measurement limits.
4. Plan populated-schema changes as additive change, backfill, verification, cutover and later cleanup where needed; retain compatibility and a realistic recovery path.
5. Rehearse changes on disposable data; check duplicates, orphans, concurrency and restartability where relevant.
6. Execute only within the authorized environment; verify integrity after the change and distinguish rehearsed recovery from written plans.

## Decision rules and boundaries

Do not run destructive production migrations from document approval alone. Preserve a tested recovery path. Avoid assuming a database rollback restores external side effects. Use exact money types, explicit units, and consistent timestamps. Define transaction boundaries and concurrency handling.

## Tools and evidence

Select and read this skill before specialist execution; apply its relevant steps rather than merely naming it. Inspect actual project commands and installed versions before choosing tools. Use official references for uncertain or version-sensitive technical claims. Load only supporting skills justified by the task; reselect when scope crosses a new boundary.

For substantial work, tie acceptance criteria to changed artifacts and actual check results. Distinguish selected, loaded, applied and verified: reading proves only loading. Keep a brief record of applied skills, meaningful commands/results, limitations and justified deviations; a concise final summary suffices for a small task. Do not run ritual tests or weaken required checks to claim success. If tools or access are unavailable, finish useful authorized work, mark dependent verification blocked or unverified, and state the next concrete check. Never invent evidence or treat Markdown as tool-level enforcement.

## Quality checks

Check duplicates, orphan records, null behavior, concurrent writes, migration compatibility, and representative query plans. Rehearse changes on a disposable copy or synthetic data before production execution.

## Deliverable

Schema/migration, integrity results, representative query evidence, compatibility and recovery limits.

## Example

“Rename a populated column.” Consider old application compatibility, dual-read transition or additive migration, backfill verification, and safe cutover.

## Skill coordination

Use kad-backend-api for application compatibility, kad-security-engineering for data access and kad-devops-delivery for migration sequencing during release.

## Completion rule

Report completion only for acceptance criteria supported by evidence. Mark partial, blocked or unverified work explicitly. Explain material deviations and their effects; use expert judgment within the user’s scope and host rules. Reuse existing authorization; this skill grants no new permissions.
