# Build Governance Platform — Design Token & Component Library Specification
**Document Reference:** BGP-DS-DOC-001  
**Controlling Baselines:** FE-APR-001, FE-084, FE-085, WCAG 2.2 AA  
**Theme Context:** Rigorous SDLC Governance Engine (`#0f172a`, `surface: #f8f9ff`, `font: Inter`, `roundness: round-sm / 4px`)  
**Date:** 20 September 2026  

---

## 1. Executive Summary & Design System Invariants

The Build Governance Platform (PM/SDLC Tracker) requires a resilient, deterministic, and highly legible visual system tailored for mission-critical institutional governance, cryptographic ledger attestation, and strict multi-party separation-of-duty controls. 

In accordance with **FE-085**, visual styling, typography scales, color assignments, spacing grids, and component interaction states are rigorously tokenized rather than left to individual developer discretion. Every UI component satisfies **FE-075 through FE-086** (WCAG 2.2 AA conformance, 44×44px minimum touch targets, keyboard navigation traps prevention, state announcements, and color-blind safe status pairing).

---

## 2. Design Tokens Catalog

### 2.1 Color Palette & Semantic Tokens

All foreground/background combinations guarantee a minimum contrast ratio of **4.5:1** for normal text and **3:1** for large text and UI boundaries. Status tokens pair distinctive hues with persistent icon glyphs and text labels (**FE-080**).

| Token Name | Hex Code | Purpose / Semantic Role | Contrast (on Surface) |
| :--- | :--- | :--- | :--- |
| `--bg-surface` | `#f8f9ff` | Global root screen background | N/A (Canvas base) |
| `--bg-surface-low` | `#eff4ff` | Subtle grouping wells, table headers, inactive tabs | 1.1:1 |
| `--bg-card` | `#ffffff` | Elevated primary cards, drawers, modals, table rows | 1.05:1 |
| `--bg-card-muted` | `#f1f5f9` | Secondary card slots, code wells, metadata tags | 1.15:1 |
| `--border-subtle` | `#e2e8f0` | Standard card borders, divider rules, subtle separators | 1.3:1 |
| `--border-strong` | `#cbdbf5` | Institutional ledger frames, active card containers | 1.8:1 |
| `--border-focus` | `#2563eb` | Active focus rings (`2px outline-offset: 2px`) | 4.8:1 |
| `--text-primary` | `#0f172a` | Headers, authoritative titles, primary data values | **17.2:1** |
| `--text-secondary` | `#475569` | Field labels, descriptive body copy, secondary timestamps | **7.1:1** |
| `--text-muted` | `#64748b` | Captions, digest annotations, breadcrumb delimiters | **4.6:1** |
| `--primary-action` | `#0f172a` | Primary CTA backgrounds, high-contrast decision buttons | **17.2:1** |
| `--primary-action-text` | `#ffffff` | Primary CTA text & icons | **17.2:1** |
| `--status-pass-bg` | `#f0fdf4` | Passed checks, verified ledgers, approved decisions | Light tint |
| `--status-pass-text` | `#15803d` | Passed status typography, checkmark icons | **5.4:1** |
| `--status-pass-border` | `#bbf7d0` | Verified boundary stroke | Accessible border |
| `--status-warn-bg` | `#fefce8` | Conditional approval, quarantine items, expiration warning | Light tint |
| `--status-warn-text` | `#a16207` | Warning typography, clock/triangle icons | **5.1:1** |
| `--status-warn-border` | `#fef08a` | Warning boundary stroke | Accessible border |
| `--status-danger-bg` | `#fef2f2` | Blocking gates, failed integrity, revoked permissions | Light tint |
| `--status-danger-text`| `#b91c1c` | Blocker typography, hard-stop indicators | **6.1:1** |
| `--status-danger-border`| `#fecaca` | Blocker boundary stroke | Accessible border |
| `--status-neutral-bg` | `#f8fafc` | Draft, supersession history, read-only items | Neutral tint |
| `--status-neutral-text`| `#475569` | Historical notes, unversioned reference text | **7.1:1** |
| `--status-neutral-border`| `#e2e8f0`| Historical block boundary stroke | Accessible border |

### 2.2 Typography Scale (Inter Font Family)

The typographic hierarchy enforces strict editorial structure. Monospace strings (`ui-monospace`, `SFMono-Regular`, `Consolas`) are strictly applied to cryptographic digests, commit hashes, Merkle root addresses, and AST declarative rules.

| Style Token | Font Size | Line Height | Weight | Tracking | Purpose / Usage |
| :--- | :--- | :--- | :--- | :--- | :--- |
| `type-display` | `24px` (`1.5rem`) | `32px` | 700 (Bold) | `-0.02em` | Page Title (H1), Mobile Screen Title |
| `type-title-lg` | `20px` (`1.25rem`)| `28px` | 700 (Bold) | `-0.01em` | Major Section Header, Gateway Cards |
| `type-title-md` | `16px` (`1.0rem`) | `24px` | 600 (Semibold)| `-0.01em` | Card Titles, Drawer Headings |
| `type-title-sm` | `14px` (`0.875rem`)| `20px` | 600 (Semibold)| `0.0em` | Form Section Headers, Tab Labels |
| `type-body` | `14px` (`0.875rem`)| `20px` | 400 (Regular) | `0.0em` | Primary Body Text, Field Inputs, Table Cells |
| `type-body-sm` | `13px` (`0.8125rem`)| `18px`| 400 (Regular) | `0.0em` | Explanatory Hints, Audit Subtitles |
| `type-caption` | `12px` (`0.75rem`) | `16px` | 500 (Medium) | `0.01em` | Status Badges, Secondary Meta, Chips |
| `type-overline` | `11px` (`0.6875rem`)| `14px` | 700 (Bold) | `0.05em` (Uppercase) | Category Tags, Tenant Scopes, FE References |
| `type-mono` | `12px` (`0.75rem`) | `16px` | 500 (Mono) | `0.0em` | SHA-256 Hashes, Revisions, Key IDs |
| `type-mono-sm` | `11px` (`0.6875rem`)| `14px`| 500 (Mono) | `0.0em` | Compact Digests, Proof Manifests |

### 2.3 Spatial Rhythm, Borders & Elevation

| Token Name | Value | Purpose |
| :--- | :--- | :--- |
| `--space-1` | `4px` (`0.25rem`) | Micro gaps, badge internal padding, icon offsets |
| `--space-2` | `8px` (`0.5rem`) | Compact padding, button horizontal inset, chip gaps |
| `--space-3` | `12px` (`0.75rem`) | Standard input vertical padding, item stack gap |
| `--space-4` | `16px` (`1.0rem`) | Standard card padding, section element spacing |
| `--space-6` | `24px` (`1.5rem`) | Major card internal padding, layout column gap |
| `--space-8` | `32px` (`2.0rem`) | Desktop grid separation, section blocks |
| `--radius-sm` | `4px` | Buttons, inputs, badges, micro-tags (`roundness: round-sm`) |
| `--radius-md` | `6px` | Standard cards, segmented controls, table containers |
| `--radius-lg` | `8px` | Modal dialogs, major dashboard widgets |
| `--radius-full` | `9999px` | Circular avatar frames, pill tags |
| `--shadow-card` | `0 1px 3px 0 rgba(0, 0, 0, 0.05), 0 1px 2px -1px rgba(0, 0, 0, 0.05)` | Default card elevation |
| `--shadow-popover`| `0 10px 15px -3px rgba(0, 0, 0, 0.08), 0 4px 6px -4px rgba(0, 0, 0, 0.04)` | Dropdowns, modals, contextual menus |

---

## 3. Accessible Component Library Specifications (FE-084)

### 3.1 Buttons & Action Controls (FE-004, FE-076, FE-078)
Every interactive button maintains a minimum touch target bounding box of **44×44px** (using transparent padding where visual size is smaller).

* **Primary CTA (`.btn-primary`)**:
  - *Styling*: Background `#0f172a`, Text `#ffffff`, Border `#0f172a`, Radius `4px`, Font `14px / 600`.
  - *States*: Hover (`#1e293b`), Focus (`outline: 2px solid #2563eb; offset: 2px`), Active (`#020617`), Disabled (`opacity: 0.5; pointer-events: none`).
  - *Usage*: One per screen for clear hierarchy (**FE-004**), e.g., `Publish Immutable Version`, `Confirm Decision`, `Initiate Cryptographic Export`.
* **Secondary / Outline Action (`.btn-secondary`)**:
  - *Styling*: Background `#ffffff`, Text `#0f172a`, Border `1px solid #cbdbf5`, Radius `4px`, Font `14px / 600`.
  - *States*: Hover (`#f8fafc; border-color: #94a3b8`), Focus (`outline: 2px solid #2563eb`), Active (`#f1f5f9`).
  - *Usage*: Paired operational triggers, e.g., `Export Ledger Proof`, `Simulate Dry-Run`, `Inspect Keys`.
* **Destructive / Danger Button (`.btn-danger`)**:
  - *Styling*: Background `#fef2f2`, Text `#b91c1c`, Border `1px solid #fecaca`, Radius `4px`, Font `14px / 600`.
  - *States*: Hover (`#fee2e2`), Focus (`outline: 2px solid #dc2626`), Active (`#fca5a5`).
  - *Usage*: Irreversible operations, e.g., `Terminate All Other Active Sessions`, `Purge Quarantine Bundle`.

---

### 3.2 Status Badges & Verification Indicators (FE-080)
Status indicators are never conveyed through color alone; they always incorporate high-contrast text and a geometric SVG glyph.

* **Approved / Complete / Policy Satisfied (`.badge-success`)**:
  - *Structure*: `<span class="badge-success"><svg>check-circle</svg> Approved</span>`
  - *Visual*: Background `#f0fdf4`, Text `#15803d`, Border `1px solid #bbf7d0`, Radius `4px`.
* **Conditional / Action Required / Warning (`.badge-warning`)**:
  - *Structure*: `<span class="badge-warning"><svg>alert-triangle</svg> Conditional (48h)</span>`
  - *Visual*: Background `#fefce8`, Text `#a16207`, Border `1px solid #fef08a`, Radius `4px`.
* **Blocked / Hard-Stop / Integrity Failure (`.badge-danger`)**:
  - *Structure*: `<span class="badge-danger"><svg>shield-x</svg> Mandatory Blocker</span>`
  - *Visual*: Background `#fef2f2`, Text `#b91c1c`, Border `1px solid #fecaca`, Radius `4px`.
* **Immutable / Superseded / Historical (`.badge-neutral`)**:
  - *Structure*: `<span class="badge-neutral"><svg>clock-rewind</svg> Superseded</span>`
  - *Visual*: Background `#f8fafc`, Text `#475569`, Border `1px solid #e2e8f0`, Radius `4px`.

---

### 3.3 Form Inputs, Validation Summaries & Real-Time Save Indicators (FE-028, FE-034, FE-079, FE-080)

* **Text Field & Dropdown Containers**:
  - *Styling*: Height `40px` (Desktop) / `44px` (Mobile), Background `#ffffff`, Border `1px solid #cbd5e1`, Text `#0f172a`, Padding `0 12px`, Radius `4px`.
  - *Accessibility*: Explicit `<label for="id">` paired with `aria-describedby` pointing to validation or constraint helper text.
  - *Focus State*: Visible `2px` focus ring in `#2563eb` with zero layout shifting.
  - *Invalid State*: Border `#dc2626`, paired with an inline error message (`.field-error`) having `role="alert"`.
* **Validation Error Summary Container (FE-079)**:
  - *Structure*: Positioned at the top of forms on failed submission; automatically receives programmatic focus (`tabindex="-1"`).
  - *Visual*: Background `#fef2f2`, Border `1px solid #f87171`, Text `#991b1b`, containing an unordered list of direct links targeting failing inputs.
* **Truthful Save Status Badge (FE-034, FE-080)**:
  - *Live Region*: `aria-live="polite"` container dynamically toggling:
    - **Saving**: Spinner animation + *"Committing revision to server..."*
    - **Saved**: Green checkmark + *"Saved to Ledger • Attested 14:32:01 UTC"*
    - **Not Saved**: Red alert icon + *"Network failure • Draft cached in secure session"*

---

### 3.4 Cryptographic Digest & Ledger Cards (FE-032, FE-058)
Purpose-built governance component for non-repudiation and Merkle tree audit inspection.

* **Visual Blueprint**:
  - Encapsulated in `--bg-card` with an authoritative header: `sha256:4a88...c019`.
  - Includes a one-tap `Inspect Digest` / `Copy Hash` action with visible screen-reader feedback (`aria-live="polite"`).
  - Explicit disclaimer: *"Local display does not infer regulatory compliance without authoritative server-side receipt check (FE-058)."*

---

### 3.5 Separation of Duty (SoD) & Quorum Control Widgets (FE-016, FE-060)

* **Signer Quorum Segmented Switch**:
  - Radio group styled as tactile segmented pills (`1 Solo`, `2 (4-Eyes)`, `3 Consensus`).
  - Active selection receives dark navy fill (`#0f172a`) with white typography and explicit `aria-checked="true"`.
* **Platform Invariant Banner (FE-066)**:
  - Locked card with icon `lock` and label `PLATFORM INVARIANT: NON-BYPASSABLE`.
  - Clear rationale text: *"The principal who authored or submitted an evidence package is cryptographically barred from approving the corresponding gate decision."*

---

### 3.6 Navigation Bars & Persistent Shells (FE-001, FE-076, FE-077)

* **Desktop Dashboard Navigation (`web_dashboard`)**:
  - Top Bar: Fixed `56px` height, corporate logo (`{{DATA:IMAGE:IMAGE_43}}`), active tenant badge (`PROD-EAST-01`), project switcher, and user avatar (`{{DATA:IMAGE:IMAGE_42}}`).
  - Left Sidebar: `240px` persistent width, grouped into *Governance Overview*, *Gates & Occurrences*, *Evidence Repository*, *Audit Ledger*, and *Administration*.
* **Mobile Shell Navigation (`mobile_tab`)**:
  - Top Header: Compact institutional bar with brand mark, tenant pill, and profile indicator.
  - Bottom Tab Bar: Fixed `64px` thumb bar with 4 standard tabs (`Projects`, `My Work`, `Gates`, `Audit`).
  - Active tab receives filled icon and semibold label in primary navy; inactive tabs render in neutral muted slate (`#64748b`).

---

## 4. Engineering Implementation Guide & CSS Classes

```css
/* Core CSS Custom Properties Baseline */
:root {
  --font-family-sans: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  --font-family-mono: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;

  --color-surface: #f8f9ff;
  --color-surface-container: #ffffff;
  --color-surface-muted: #f1f5f9;
  
  --color-border: #cbdbf5;
  --color-border-subtle: #e2e8f0;
  
  --color-primary: #0f172a;
  --color-primary-hover: #1e293b;
  --color-primary-text: #ffffff;
  
  --color-success-bg: #f0fdf4;
  --color-success-text: #15803d;
  --color-success-border: #bbf7d0;

  --color-warning-bg: #fefce8;
  --color-warning-text: #a16207;
  --color-warning-border: #fef08a;

  --color-danger-bg: #fef2f2;
  --color-danger-text: #b91c1c;
  --color-danger-border: #fecaca;
  
  --radius-default: 4px;
}

/* Touch Target Minimum Enforcement */
.btn, .input-field, .tab-item, .filter-chip {
  min-height: 44px;
  min-width: 44px;
  box-sizing: border-box;
}

/* Accessible Focus Ring */
*:focus-visible {
  outline: 2px solid #2563eb !important;
  outline-offset: 2px !important;
}

/* Cryptographic Monospace Formatter */
.crypto-hash {
  font-family: var(--font-family-mono);
  font-size: 11px;
  letter-spacing: 0.02em;
  color: #334155;
}
```

---

## 5. Traceability Matrix to Approved Requirements

| Component / Token System | Baseline ID | Requirement Enforced |
| :--- | :--- | :--- |
| **Theme & Typography** | FE-085, DEC04 | Deterministic tokens across all 10 desktop & 10 mobile screens |
| **Color & Contrast** | FE-075, FE-081 | WCAG 2.2 AA compliant contrast (≥4.5:1) |
| **Status Pairing** | FE-080 | Status color strictly paired with text and iconography |
| **Truthful Save State** | FE-034, FE-080 | Accurate representation of Saving vs. Saved vs. Not Saved |
| **Touch Ergonomics** | FE-076, FE-078 | Full feature completion on mobile with ≥44px touch targets |
| **Accessible Focus** | FE-078, FE-079 | Visible 2px focus indicators without keyboard traps |
| **SoD Invariant Cards** | FE-016, FE-066 | Immutable author-checker isolation visualization |
| **Cryptographic Proofs** | FE-032, FE-058 | Visual representation of hash trees and verification rules |
