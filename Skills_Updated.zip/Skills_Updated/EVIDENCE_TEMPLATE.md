# Task evidence record

Use for substantial work; keep a short summary for small changes.

Task and acceptance criteria:
Scope and inspected revision:
Selected skills and content versions:
Loading evidence, if observable:
Applied procedures and resulting artifacts:

| Criterion | Actual check / artifact | Observed result | Status |
| --- | --- | --- | --- |

Record passed, failed, blocked or unverified accurately. Do not infer a pass from missing evidence. For UI work include visual direction, states/viewports inspected, interaction results and integration limits. Keep screenshots free of personal data.

Material deviations and reasons:
Outstanding limitations and next check:
Delivery state: implemented / verified / packaged / installed / deployed, as actually applicable.
