---
name: kad-code-review
description: "Use to review a patch, pull request, or implementation for actionable correctness and maintenance risks."
---

# Code Review

## Purpose and inputs

Apply this workflow to the requested task without expanding its scope. Use diff, surrounding code and callers, requirements, test evidence, and project conventions.

## Workflow

1. Read the requested diff, requirements, surrounding callers and available test evidence.
2. Trace changed input, state and side effects; prioritise correctness, authorization, data loss and compatibility.
3. Investigate suspected defects in context and reproduce uncertain concerns when feasible.
4. Report actionable findings with location, triggering conditions, impact and a concrete correction direction; separate suggestions from defects.
5. Check each finding is not already handled elsewhere; state inspected scope and verification gaps even when no actionable defect is found.

## Decision rules and boundaries

Do not report stylistic preferences as defects or invent findings to fill a quota. Separate blocking defects from suggestions. Treat missing evidence as a verification gap. Review approval is limited to inspected scope and cannot replace release authorization.

## Tools and evidence

Select and read this skill before specialist execution; apply its relevant steps rather than merely naming it. Inspect actual project commands and installed versions before choosing tools. Use official references for uncertain or version-sensitive technical claims. Load only supporting skills justified by the task; reselect when scope crosses a new boundary.

For substantial work, tie acceptance criteria to changed artifacts and actual check results. Distinguish selected, loaded, applied and verified: reading proves only loading. Keep a brief record of applied skills, meaningful commands/results, limitations and justified deviations; a concise final summary suffices for a small task. Do not run ritual tests or weaken required checks to claim success. If tools or access are unavailable, finish useful authorized work, mark dependent verification blocked or unverified, and state the next concrete check. Never invent evidence or treat Markdown as tool-level enforcement.

## Quality checks

Confirm every finding is supported and not already handled elsewhere. Check tests against the behavior at risk. Say when no actionable defect was found and describe material review limits.

## Deliverable

Prioritized evidence-backed findings and scoped conclusion; no invented issue quota, silent edits during a read-only review, or unsupported approval.

## Example

“Review this login change.” Trace token issuance, expiry, session invalidation, password verification, and error behavior through the changed paths.

## Skill coordination

Use the affected engineering domain and kad-security-engineering for sensitive paths. For requested refactoring load kad-programming and verify preserved behaviour.

## Completion rule

Report completion only for acceptance criteria supported by evidence. Mark partial, blocked or unverified work explicitly. Explain material deviations and their effects; use expert judgment within the user’s scope and host rules. Reuse existing authorization; this skill grants no new permissions.
