---
name: kad-delivery-change-management
description: "Use for implementation planning, stage readiness, scope changes, release coordination, and evidence-based acceptance."
---

# Delivery and Change Management

## Purpose and inputs

Apply this workflow to the requested task without expanding its scope. Use baseline scope, requirement IDs, dependencies, risks, available capacity, acceptance evidence, and decision authority.

## Workflow

1. Read the current scope, existing decisions, dependencies, risks and actual authorization.
2. Break work into increments with owners or explicit ownership gaps, prerequisites, deliverables and acceptance evidence.
3. Assess proposed changes against behaviour, schedule, data, security and operations before updating the baseline.
4. Track implemented, verified, blocked and deferred items; attach real artifact/test references to completed gates.
5. Prepare release/recovery/support needs proportionate to the change and record the actual decision within its scope.
6. Distinguish document adoption, development readiness, test acceptance, deployment authorization and production success.

## Decision rules and boundaries

Distinguish document approval, development readiness, test acceptance, deployment authorization, and production success. Reuse authorization already given for a concrete action; do not repeatedly seek it. Never fabricate a signature, stakeholder decision, schedule, or completed gate.

## Tools and evidence

Select and read this skill before specialist execution; apply its relevant steps rather than merely naming it. Inspect actual project commands and installed versions before choosing tools. Use official references for uncertain or version-sensitive technical claims. Load only supporting skills justified by the task; reselect when scope crosses a new boundary.

For substantial work, tie acceptance criteria to changed artifacts and actual check results. Distinguish selected, loaded, applied and verified: reading proves only loading. Keep a brief record of applied skills, meaningful commands/results, limitations and justified deviations; a concise final summary suffices for a small task. Do not run ritual tests or weaken required checks to claim success. If tools or access are unavailable, finish useful authorized work, mark dependent verification blocked or unverified, and state the next concrete check. Never invent evidence or treat Markdown as tool-level enforcement.

## Quality checks

Verify each completed item has evidence and each blocker has a next action. Check that rollback, support, and training needs are addressed in proportion to the release. Identify unresolved conditions explicitly.

## Deliverable

Implementable plan or change/release record, dependencies, evidence, exact decision scope and unresolved next actions.

## Example

“Approve everything for use.” Record approval for the reviewed documents and instructions; evaluate a future system release using its actual tests and deployment authority.

## Skill coordination

Use kad-requirements-analysis for scope, kad-project-assessment for status and relevant domain/testing skills for gate evidence.

## Completion rule

Report completion only for acceptance criteria supported by evidence. Mark partial, blocked or unverified work explicitly. Explain material deviations and their effects; use expert judgment within the user’s scope and host rules. Reuse existing authorization; this skill grants no new permissions.
