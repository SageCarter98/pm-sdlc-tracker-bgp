# Skill catalogue — version 1.1.0

Select the primary skill from task intent, read it and apply its workflow. Add supporting skills when the task crosses a relevant boundary. Do not load all skills by default. Software design is covered by architecture and programming; refactoring by programming and code review.

| Skill | Selection guidance |
| --- | --- |
| [kad-backend-api](.agents/skills/kad-backend-api/SKILL.md) | Use for server-side business logic, HTTP APIs, service integrations, authentication flows, and background jobs. |
| [kad-code-review](.agents/skills/kad-code-review/SKILL.md) | Use to review a patch, pull request, or implementation for actionable correctness and maintenance risks. |
| [kad-data-ai-engineering](.agents/skills/kad-data-ai-engineering/SKILL.md) | Use for data pipelines, analytics, machine learning, retrieval systems, AI agents, and model evaluation. |
| [kad-database-engineering](.agents/skills/kad-database-engineering/SKILL.md) | Use for relational or document schemas, queries, indexes, migrations, transactions, and data integrity. |
| [kad-debugging](.agents/skills/kad-debugging/SKILL.md) | Use to investigate defects, runtime errors, failed builds, or unexpected system behavior. |
| [kad-delivery-change-management](.agents/skills/kad-delivery-change-management/SKILL.md) | Use for implementation planning, stage readiness, scope changes, release coordination, and evidence-based acceptance. |
| [kad-devops-delivery](.agents/skills/kad-devops-delivery/SKILL.md) | Use for build pipelines, containers, environment configuration, deployments, and release automation. |
| [kad-documentation-handover](.agents/skills/kad-documentation-handover/SKILL.md) | Use for implementation guides, technical explanations, runbooks, user manuals, and maintainable handover documentation. |
| [kad-engineering-conduct](.agents/skills/kad-engineering-conduct/SKILL.md) | Use when starting substantial engineering work, resolving conflicting instructions, or deciding whether an action is authorized. |
| [kad-frontend-engineering](.agents/skills/kad-frontend-engineering/SKILL.md) | Use to build, redesign or repair frontend interfaces, visual design, responsive layouts, accessibility and integrated user journeys. Apply to attractive UI requests; verify rendered appearance and behaviour, not only builds. |
| [kad-git-collaboration](.agents/skills/kad-git-collaboration/SKILL.md) | Use for branches, commits, conflict resolution, pull request preparation, and safe repository collaboration. |
| [kad-human-communication](.agents/skills/kad-human-communication/SKILL.md) | Use when explaining engineering decisions, writing user-facing messages, teaching a technical concept, or revising text for natural language. |
| [kad-infrastructure-networks](.agents/skills/kad-infrastructure-networks/SKILL.md) | Use for server administration, network diagnosis, DNS, TLS, firewall rules, and infrastructure configuration. |
| [kad-performance-reliability](.agents/skills/kad-performance-reliability/SKILL.md) | Use for measured latency or resource problems, capacity planning, reliability targets, incident response, and recovery design. |
| [kad-programming](.agents/skills/kad-programming/SKILL.md) | Use to implement application logic, algorithms, command-line tools and behaviour-preserving refactors in an existing stack. Pair with frontend, backend or database skills for specialist work. |
| [kad-project-assessment](.agents/skills/kad-project-assessment/SKILL.md) | Use to assess an existing repository, blueprint, implementation status, or readiness for the next development stage. |
| [kad-requirements-analysis](.agents/skills/kad-requirements-analysis/SKILL.md) | Use to turn an idea or change request into testable product requirements and acceptance criteria. |
| [kad-security-engineering](.agents/skills/kad-security-engineering/SKILL.md) | Use for defensive threat modelling, secure implementation, access control reviews, and authorized vulnerability remediation. |
| [kad-software-architecture](.agents/skills/kad-software-architecture/SKILL.md) | Use for software design, architecture, major structural changes, component boundaries, interface contracts and justified design patterns. For a small local refactor use kad-programming. |
| [kad-testing-quality](.agents/skills/kad-testing-quality/SKILL.md) | Use to design meaningful test coverage, verify behavior changes, and assess acceptance evidence. |
