---
name: kad-project-assessment
description: "Use to assess an existing repository, blueprint, implementation status, or readiness for the next development stage."
---

# Project Assessment

## Purpose and inputs

Apply this workflow to the requested task without expanding its scope. Use approved baseline if accessible, repository state, build instructions, tests, deployment evidence, and known findings.

## Workflow

1. Identify the exact supplied revision or snapshot and the approved baseline that is actually accessible.
2. Inspect project structure, setup instructions, dependencies, source and relevant checks rather than relying on screenshots or directory names.
3. Trace one critical journey through UI, API, authorization and persistence where present; record which boundaries remain unverified.
4. Map requirements to implemented, verified, missing or inaccessible evidence; rank gaps by user impact and dependencies.
5. Recheck claimed closures against current artifacts and give a scoped readiness conclusion.

## Decision rules and boundaries

Treat a working screen as insufficient proof of connected persistence, authorization, or production readiness. If a private repository is unavailable, assess supplied artifacts and explicitly narrow the conclusion. Keep organization-wide governance separate from project-specific requirements.

## Tools and evidence

Select and read this skill before specialist execution; apply its relevant steps rather than merely naming it. Inspect actual project commands and installed versions before choosing tools. Use official references for uncertain or version-sensitive technical claims. Load only supporting skills justified by the task; reselect when scope crosses a new boundary.

For substantial work, tie acceptance criteria to changed artifacts and actual check results. Distinguish selected, loaded, applied and verified: reading proves only loading. Keep a brief record of applied skills, meaningful commands/results, limitations and justified deviations; a concise final summary suffices for a small task. Do not run ritual tests or weaken required checks to claim success. If tools or access are unavailable, finish useful authorized work, mark dependent verification blocked or unverified, and state the next concrete check. Never invent evidence or treat Markdown as tool-level enforcement.

## Quality checks

Check that each finding is reproducible or clearly labelled as an inference. Recheck claimed closures against current artifacts. Avoid counting inaccessible evidence as a failure or a pass.

## Deliverable

Evidence matrix with source locations, inspected revision, reproducible findings, confidence and next actions; inaccessible evidence stays unknown.

## Example

“Is the frontend ready?” Compare journeys, responsive states, accessibility, API contracts, authorization behavior, and end-to-end evidence.

## Skill coordination

Use domain skills to assess their implementation, kad-code-review for patch defects and kad-delivery-change-management for readiness decisions.

## Completion rule

Report completion only for acceptance criteria supported by evidence. Mark partial, blocked or unverified work explicitly. Explain material deviations and their effects; use expert judgment within the user’s scope and host rules. Reuse existing authorization; this skill grants no new permissions.
