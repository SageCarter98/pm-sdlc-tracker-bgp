# Build Governance Platform — Complete Frontend Specification & Token Bundle
**Document Reference:** BGP-SPEC-BUNDLE-V1.0  
**Controlling Baselines:** FE-APR-001, Blueprint v0.2, FE-001..FE-102, DEC01..DEC12, WCAG 2.2 AA  
**Theme:** Rigorous SDLC Governance Engine (`#0f172a`, `surface: #f8f9ff`, `font: Inter`, `roundness: round-sm / 4px`)  
**Publication Date:** 20 September 2026  
**Artifact Classification:** Authoritative Engineering Export & Architecture Bundle  

---

## 1. Executive Summary & Export Scope

This export bundle provides the comprehensive, consolidated engineering specification for the **Build Governance Platform (PM/SDLC Tracker)** frontend implementation. It synthesizes all deliverables approved under **FE-APR-001**, covering:

1. **Complete Screen Architecture (20 Screens)**:
   - 10 Authoritative Desktop Views (`UI01`–`UI10`)
   - 10 Dedicated Mobile Responsive Views (`UI01`–`UI10`)
2. **Design Tokens & Component Library**:
   - Semantic CSS Custom Properties (Colors, Typography, Spacing, Elevation, Focus)
   - Component state contracts (Button, Badge, Input, Table, Ledger Card, Quorum Selector)
   - Standardized SVG glyph icons and accessible markup patterns
3. **End-to-End User Journey Traceability**:
   - Detailed step-by-step matrix for Journeys A, B, C, D, and E
4. **API Interaction & Error Handling Contracts**:
   - Complete endpoint map, idempotency rules, HTTP error envelopes, and retry policies
5. **Platform Security, Invariants & Compliance Manifest**:
   - Separation of Duties (SoD), non-bypassable WORM legal hold, and WCAG 2.2 AA validation

---

## 2. Master Screen Inventory & Route Matrix

### 2.1 Complete Screen Catalogue (Desktop & Mobile)

| Screen ID | Screen Title | Device Form Factor | Shell Layout Pattern | Primary Operational Route | Linked Requirements |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **UI01-D** | UI01 — Sign in and Invitation | Desktop (1440px) | `web_blank` (Centered Card) | `/auth/login`, `/auth/invitation/:token` | FE-010..FE-012, FE-018, FE-019 |
| **UI01-M** | UI01 — Sign in and Invitation (Mobile) | Mobile (390px) | `mobile_blank` (Full Screen) | `/auth/login`, `/auth/invitation/:token` | FE-076, FE-077, FE-010..FE-012 |
| **UI02-D** | UI02 — First Project Creation | Desktop (1440px) | `web_dashboard` (Sidebar + TopBar) | `/projects/new` | FE-021..FE-024, FE-028, Journey A |
| **UI02-M** | UI02 — First Project Creation (Mobile) | Mobile (390px) | `mobile_tab` (Tab: Projects) | `/projects/new` | FE-076, FE-077, FE-021..FE-024 |
| **UI03-D** | UI03 — My Work Task Console | Desktop (1440px) | `web_dashboard` (Sidebar + TopBar) | `/my-work` | FE-025..FE-027, FE-033, FE-001 |
| **UI03-M** | UI03 — My Work Task Console (Mobile) | Mobile (390px) | `mobile_tab` (Tab: My Work [3]) | `/my-work` | FE-076, FE-077, FE-025..FE-027 |
| **UI04-D** | UI04 — Evidence Editor & Revision Tracker | Desktop (1440px) | `web_dashboard` (Sidebar + TopBar) | `/evidence/:id/edit` | FE-029..FE-039, Journey B |
| **UI04-M** | UI04 — Evidence Editor & Revision Tracker (Mobile) | Mobile (390px) | `mobile_tab` (Tab: Projects) | `/evidence/:id/edit` | FE-076, FE-077, FE-029..FE-039 |
| **UI05-D** | UI05 — Gate Readiness Dashboard | Desktop (1440px) | `web_dashboard` (Sidebar + TopBar) | `/projects/:id/gates/:gateId` | FE-040..FE-047, Journey C |
| **UI05-M** | UI05 — Gate Readiness Dashboard (Mobile) | Mobile (390px) | `mobile_tab` (Tab: Gates) | `/projects/:id/gates/:gateId` | FE-076, FE-077, FE-040..FE-047 |
| **UI06-D** | UI06 — Governance Decision Summary & Sign-off | Desktop (1440px) | `web_dashboard` (Sidebar + TopBar) | `/occurrences/:id/decision` | FE-048..FE-054, DEC05, Journey C |
| **UI06-M** | UI06 — Governance Decision Summary & Sign-off (Mobile) | Mobile (390px) | `mobile_tab` (Tab: Gates) | `/occurrences/:id/decision` | FE-076, FE-077, FE-048..FE-054 |
| **UI07-D** | UI07 — Audit History & Supersession Tracker | Desktop (1440px) | `web_dashboard` (Sidebar + TopBar) | `/projects/:id/history` | FE-055..FE-058, Journey D |
| **UI07-M** | UI07 — Audit History & Supersession Tracker (Mobile) | Mobile (390px) | `mobile_tab` (Tab: Audit) | `/projects/:id/history` | FE-076, FE-077, FE-055..FE-058 |
| **UI08-D** | UI08 — Template Authoring & Governance Rule Builder | Desktop (1440px) | `web_dashboard` (Sidebar + TopBar) | `/admin/templates/:id` | FE-059..FE-066, DEC07, Journey E |
| **UI08-M** | UI08 — Template Authoring & Governance Rule Builder (Mobile) | Mobile (390px) | `mobile_tab` (Tab: Gates) | `/admin/templates/:id` | FE-076, FE-077, FE-059..FE-066 |
| **UI09-D** | UI09 — Export, Import & Archive Reconciliation | Desktop (1440px) | `web_dashboard` (Sidebar + TopBar) | `/data/portability` | FE-067..FE-074, DEC06, DEC12 |
| **UI09-M** | UI09 — Export, Import & Archive Reconciliation (Mobile) | Mobile (390px) | `mobile_tab` (Tab: Projects) | `/data/portability` | FE-076, FE-077, FE-067..FE-074 |
| **UI10-D** | UI10 — Account, Membership & Separation Settings | Desktop (1440px) | `web_dashboard` (Sidebar + TopBar) | `/settings/organization` | FE-010..FE-020, FE-080, FE-082 |
| **UI10-M** | UI10 — Account, Membership & Separation Settings (Mobile) | Mobile (390px) | `mobile_tab` (Tab: Projects) | `/settings/organization` | FE-076, FE-077, FE-010..FE-020 |

---

## 3. Authoritative Design Tokens (JSON & CSS Bundle)

### 3.1 Standard Token JSON (`bgp-tokens.json`)

```json
{
  "name": "Rigorous SDLC Governance Engine",
  "version": "1.0.0",
  "baseline": "FE-085",
  "color": {
    "surface": {
      "default": { "value": "#f8f9ff", "type": "color" },
      "low": { "value": "#eff4ff", "type": "color" },
      "container": { "value": "#ffffff", "type": "color" },
      "muted": { "value": "#f1f5f9", "type": "color" }
    },
    "border": {
      "subtle": { "value": "#e2e8f0", "type": "color" },
      "strong": { "value": "#cbdbf5", "type": "color" },
      "focus": { "value": "#2563eb", "type": "color" }
    },
    "text": {
      "primary": { "value": "#0f172a", "type": "color", "contrastRatio": "17.2:1" },
      "secondary": { "value": "#475569", "type": "color", "contrastRatio": "7.1:1" },
      "muted": { "value": "#64748b", "type": "color", "contrastRatio": "4.6:1" }
    },
    "action": {
      "primary": { "value": "#0f172a", "type": "color" },
      "primaryHover": { "value": "#1e293b", "type": "color" },
      "primaryText": { "value": "#ffffff", "type": "color" }
    },
    "status": {
      "pass": {
        "bg": { "value": "#f0fdf4", "type": "color" },
        "text": { "value": "#15803d", "type": "color" },
        "border": { "value": "#bbf7d0", "type": "color" }
      },
      "warn": {
        "bg": { "value": "#fefce8", "type": "color" },
        "text": { "value": "#a16207", "type": "color" },
        "border": { "value": "#fef08a", "type": "color" }
      },
      "danger": {
        "bg": { "value": "#fef2f2", "type": "color" },
        "text": { "value": "#b91c1c", "type": "color" },
        "border": { "value": "#fecaca", "type": "color" }
      },
      "neutral": {
        "bg": { "value": "#f8fafc", "type": "color" },
        "text": { "value": "#475569", "type": "color" },
        "border": { "value": "#e2e8f0", "type": "color" }
      }
    }
  },
  "typography": {
    "fontFamily": {
      "sans": { "value": "Inter, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif" },
      "mono": { "value": "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace" }
    },
    "scale": {
      "display": { "fontSize": "24px", "lineHeight": "32px", "fontWeight": "700" },
      "titleLg": { "fontSize": "20px", "lineHeight": "28px", "fontWeight": "700" },
      "titleMd": { "fontSize": "16px", "lineHeight": "24px", "fontWeight": "600" },
      "titleSm": { "fontSize": "14px", "lineHeight": "20px", "fontWeight": "600" },
      "body": { "fontSize": "14px", "lineHeight": "20px", "fontWeight": "400" },
      "bodySm": { "fontSize": "13px", "lineHeight": "18px", "fontWeight": "400" },
      "caption": { "fontSize": "12px", "lineHeight": "16px", "fontWeight": "500" },
      "mono": { "fontSize": "12px", "lineHeight": "16px", "fontWeight": "500" },
      "monoSm": { "fontSize": "11px", "lineHeight": "14px", "fontWeight": "500" }
    }
  },
  "spacing": {
    "space-1": { "value": "4px" },
    "space-2": { "value": "8px" },
    "space-3": { "value": "12px" },
    "space-4": { "value": "16px" },
    "space-6": { "value": "24px" },
    "space-8": { "value": "32px" }
  },
  "radius": {
    "sm": { "value": "4px" },
    "md": { "value": "6px" },
    "lg": { "value": "8px" },
    "full": { "value": "9999px" }
  }
}
```

### 3.2 Global CSS Custom Properties (`bgp-tokens.css`)

```css
/**
 * Build Governance Platform (BGP) — Design System Custom Properties
 * Baseline: FE-085, DEC04
 */
:root {
  /* Surface Tokens */
  --bg-surface: #f8f9ff;
  --bg-surface-low: #eff4ff;
  --bg-card: #ffffff;
  --bg-card-muted: #f1f5f9;

  /* Border Tokens */
  --border-subtle: #e2e8f0;
  --border-strong: #cbdbf5;
  --border-focus: #2563eb;

  /* Typography Tokens */
  --font-family-sans: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  --font-family-mono: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;

  --text-primary: #0f172a;
  --text-secondary: #475569;
  --text-muted: #64748b;

  /* Primary Action */
  --primary-action: #0f172a;
  --primary-action-hover: #1e293b;
  --primary-action-active: #020617;
  --primary-action-text: #ffffff;

  /* Status Colors */
  --status-pass-bg: #f0fdf4;
  --status-pass-text: #15803d;
  --status-pass-border: #bbf7d0;

  --status-warn-bg: #fefce8;
  --status-warn-text: #a16207;
  --status-warn-border: #fef08a;

  --status-danger-bg: #fef2f2;
  --status-danger-text: #b91c1c;
  --status-danger-border: #fecaca;

  --status-neutral-bg: #f8fafc;
  --status-neutral-text: #475569;
  --status-neutral-border: #e2e8f0;

  /* Spacing */
  --space-1: 4px;
  --space-2: 8px;
  --space-3: 12px;
  --space-4: 16px;
  --space-6: 24px;
  --space-8: 32px;

  /* Radii */
  --radius-sm: 4px;
  --radius-md: 6px;
  --radius-lg: 8px;
  --radius-full: 9999px;

  /* Elevation */
  --shadow-card: 0 1px 3px 0 rgba(0, 0, 0, 0.05), 0 1px 2px -1px rgba(0, 0, 0, 0.05);
  --shadow-popover: 0 10px 15px -3px rgba(0, 0, 0, 0.08), 0 4px 6px -4px rgba(0, 0, 0, 0.04);
}

/* Base Accessibility Rules */
*:focus-visible {
  outline: 2px solid var(--border-focus) !important;
  outline-offset: 2px !important;
}

.btn, .input-field, .tab-item, .filter-chip {
  min-height: 44px;
  min-width: 44px;
  box-sizing: border-box;
}

.crypto-hash {
  font-family: var(--font-family-mono);
  font-size: 11px;
  letter-spacing: 0.02em;
  color: var(--text-secondary);
}
```

---

## 4. Component Implementation Guide

### 4.1 Buttons & Interactive Controls (FE-004, FE-076, FE-078)

```html
<!-- Primary CTA: One per screen (FE-004) -->
<button type="button" class="btn btn-primary" aria-label="Confirm Gate Decision">
  <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
  </svg>
  Confirm Gate Decision
</button>

<!-- Secondary Outline Action -->
<button type="button" class="btn btn-secondary" aria-label="Export Ledger Proof">
  <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
  </svg>
  Export Ledger Proof
</button>

<!-- Destructive Action -->
<button type="button" class="btn btn-danger" aria-label="Terminate Active Sessions">
  Terminate All Other Active Sessions
</button>
```

### 4.2 Status Indicators (FE-080: Color + Text + SVG Glyph)

```html
<!-- Approved Status -->
<span class="badge badge-success" role="status">
  <svg class="w-3.5 h-3.5 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
  </svg>
  Approved
</span>

<!-- Conditional Approval Status -->
<span class="badge badge-warning" role="status">
  <svg class="w-3.5 h-3.5 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
  </svg>
  Conditional (48h Remaining)
</span>

<!-- Mandatory Blocker Status -->
<span class="badge badge-danger" role="status">
  <svg class="w-3.5 h-3.5 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636" />
  </svg>
  Mandatory Blocker
</span>
```

### 4.3 Truthful Save Status Region (FE-034, FE-080)

```html
<!-- Live Region for Form Autosave State -->
<div class="save-status-container" aria-live="polite" aria-atomic="true">
  <!-- State: Saved -->
  <span class="inline-flex items-center text-xs font-medium text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded border border-emerald-200">
    <svg class="w-3.5 h-3.5 mr-1.5 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
    </svg>
    Saved to Ledger • Attested 14:32:01 UTC
  </span>
</div>
```

---

## 5. User Journey Implementation Matrix

| Journey | Description | Entry Screen | Final Screen | Invariants Enforced |
| :--- | :--- | :--- | :--- | :--- |
| **Journey A** | First Project Creation & Seeding | `UI01` (Sign-in/MFA) | `UI03` (My Work) | Atomic project provisioning, starter template lock, idempotency key `#PRJ-INIT-2026-904`, immediate seed of first occurrence (G-01). |
| **Journey B** | Evidence Preparation & Revision Tracking | `UI03` (My Work) | `UI04` (Evidence Editor) | Strict revision increment (`r1` $\rightarrow$ `r2`), SHA-256 hash attestation, concurrent conflict detection, truthful autosave indicator. |
| **Journey C** | Gate Readiness Assessment & Quorum Sign-off | `UI05` (Readiness Dashboard) | `UI06` (Decision Summary) | Completion % never equals approval (FE-043), author-checker isolation (FE-016), manifest digest signing, dual-tap replay protection. |
| **Journey D** | Historical Audit & Decision Supersession | `UI07` (Audit History) | `UI07` (Correction View) | Immutable ledger history, zero in-place edit/delete, superseding links (`DEC-A` $\rightarrow$ `DEC-B`), sponsor review of non-member admin access. |
| **Journey E** | Governance Template Authoring & Migration | `UI08` (Template Rules) | `UI08` (Published v2.5) | Pure declarative AST rules, cycle detection, deterministic sandbox simulation (`PASS: RIGOROUS`), immutable v1 pinning for existing projects. |

---

## 6. Approved API Interaction Map & Error Envelopes

### 6.1 HTTP Endpoint Specification (Blueprint v0.2 Section 5.3)

| Frontend Action | HTTP Method & Route | Request Headers & Payload Digest | Client Validation & State Rules |
| :--- | :--- | :--- | :--- |
| **Create Project** | `POST /api/projects` | `Idempotency-Key: <UUID>`, `{ name, template_version_id, class_id }` | Atomic creation. Retry with same key guarantees no duplicate. |
| **Get My Work** | `GET /api/my-work?cursor=<id>&limit=20` | `Authorization: Bearer <JWT>` | Renders scoped tasks; suppresses unassigned or restricted project names. |
| **Submit Evidence Revision** | `POST /api/evidence/:id/revisions` | `{ base_revision, changed_fields, notes, source_hash }` | 409 Conflict triggers diff comparison view without overwriting newer revisions. |
| **Autosave Draft** | `PUT /api/drafts/:id` | `{ base_revision, payload }` | Displays `Saving` $\rightarrow$ `Saved` only upon `200 OK`. Offline displays `Not Saved`. |
| **Preview Decision** | `POST /api/occurrences/:id/preview` | `{ proposed_outcome, conditions, permitted_activities }` | Returns evaluated readiness digest (`manifest_sha256`). Locks preview snapshot. |
| **Confirm Decision** | `POST /api/occurrences/:id/decisions` | `Idempotency-Key: <UUID>`, `{ manifest_sha256, reviewed_revision, outcome }` | Requires FIDO2/WebAuthn assertion. Returns authoritative decision ID. |
| **Supersede Decision** | `POST /api/decisions/:id/superseding` | `{ original_decision_id, reason, corrective_evidence, outcome }` | Creates new immutable record pointing back to original id. |
| **Publish Template** | `POST /api/templates/:id/publish` | `{ draft_revision, ast_validation_receipt }` | Freezes template version. Generates immutable revision ID. |
| **Initiate Export** | `POST /api/exports` | `{ scope, format_version, include_revisions }` | Polling job tracker. Available even during delinquent billing state. |

### 6.2 Standardized Error Envelope (FE-088)

```json
{
  "error": {
    "code": "SOD_INVARIANT_VIOLATION",
    "status": 403,
    "message": "Separation of Duty Violation: Evidence author (David Chen) is cryptographically prohibited from approving Production Release Gate G-04.",
    "field_violations": [
      {
        "field": "approver_id",
        "rule": "FE-016_AUTHOR_CHECKER_ISOLATION",
        "description": "Approver identity matches evidence committer on revision r3."
      }
    ],
    "remediation": {
      "action": "DELEGATE_REVIEW",
      "required_role": "INDEPENDENT_LEAD_APPROVER",
      "eligible_principals": ["Elena Vance", "Dr. Marcus Sterling"]
    },
    "correlation_id": "err-bgp-2026-9481a0",
    "timestamp": "2026-09-20T14:32:00Z"
  }
}
```

---

## 7. Platform Invariants & Compliance Verification Checklists

### 7.1 Separation of Duties (SoD) & Platform Invariants (FE-016, FE-066)
* [x] **Author-Checker Isolation**: The principal authoring or modifying an evidence item is permanently barred from executing the approval decision for that occurrence.
* [x] **Dual-Control Quorum**: Critical gates (Tier-1 Banking Release) enforce a minimum 2-distinct-signer quorum (e.g., Lead Approver + External Assessor).
* [x] **Immutable WORM Storage**: Recorded decisions, audit chains, and export archives cannot be altered or deleted. Under DEC06 / SEC 17a-4, retention holds are cryptographically enforced for 7 years (minimum expiration: `2033-04-18 UTC`).
* [x] **Billing Resilience Guarantee (FE-069)**: Audit histories, cryptographic export tools, and MFA access remain 100% active and un-paywalled regardless of account payment status.

### 7.2 Accessibility (WCAG 2.2 AA) Conformance Checklist (FE-075..FE-086)
* [x] **Contrast Ratios (FE-075, FE-081)**: Normal text achieves $\ge 4.5:1$; large headers and UI boundaries achieve $\ge 3:1$ (`#0f172a` on `#f8f9ff` achieves $17.2:1$).
* [x] **Touch Ergonomics (FE-076, FE-078)**: 100% of interactive mobile elements maintain bounding boxes $\ge 44\times 44\text{px}$.
* [x] **Keyboard Navigation & Traps (FE-078, FE-079)**: Full tab index predictability, visible `2px` focus outline with `2px` offset, zero drag-and-drop dependencies, and automatic focus shift to validation error summaries.
* [x] **Assistive Technology Announcements (FE-080)**: Live regions (`aria-live="polite"`) configured for autosave statuses, digest verification, and clipboard actions. Statuses strictly pair geometric SVG icons with text labels.

---

## 8. Export Authorization & Distribution Notice

**Document Reference:** BGP-SPEC-BUNDLE-V1.0  
**Authority:** FE-APR-001 Approved Baseline  
**Distribution:** Engineering Leads, Frontend Developers, QA Automation Teams, and Regulatory Compliance Officers.  
*All deliverables defined herein are finalized, reproducible, and bound to the persistent project DataStore and Canvas surfaces.*
