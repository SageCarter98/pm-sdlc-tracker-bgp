---
name: kad-frontend-engineering
description: "Use to build, redesign or repair frontend interfaces, visual design, responsive layouts, accessibility and integrated user journeys. Apply to attractive UI requests; verify rendered appearance and behaviour, not only builds."
---

# Frontend Engineering

## Purpose and inputs

Apply this workflow to the requested task without expanding its scope. Use user journeys, design system, API contracts, roles, devices, content, and existing frontend code.

## Workflow

1. Inspect users, primary journeys, roles, content, device needs, existing components and API contracts.
2. Read references/visual-quality.md for new screens, redesigns or visual defects. Establish a product-appropriate visual direction and reusable typography, colour, spacing and layout values; preserve a sound existing design system.
3. Map required screen states: loading, empty, success, validation failure, network failure and denied access. Build one complete representative journey before propagating its patterns.
4. Implement semantic reusable components, keyboard operation, visible focus, helpful feedback and responsive layouts with realistic content.
5. Connect supported data contracts, handle stale requests and duplicate submissions, and verify persistence where available. Label mock integration and keep authorization enforced on the server.
6. Render and inspect representative narrow, medium and wide layouts; exercise the main journey and failure recovery. Correct material visual and functional defects, then rerun affected checks.
7. Record visual inspection separately from builds and interaction tests; disclose unavailable browser or backend verification rather than declaring full completion.

## Decision rules and boundaries

Reuse the established visual system. Keep client-side permission checks for presentation while relying on server enforcement. Avoid optimistic updates for irreversible or financially sensitive actions unless reconciliation is designed. Do not substitute mock data for working integration without clear labelling.

## Tools and evidence

Select and read this skill before specialist execution; apply its relevant steps rather than merely naming it. Inspect actual project commands and installed versions before choosing tools. Use official references for uncertain or version-sensitive technical claims. Load only supporting skills justified by the task; reselect when scope crosses a new boundary.

For substantial work, tie acceptance criteria to changed artifacts and actual check results. Distinguish selected, loaded, applied and verified: reading proves only loading. Keep a brief record of applied skills, meaningful commands/results, limitations and justified deviations; a concise final summary suffices for a small task. Do not run ritual tests or weaken required checks to claim success. If tools or access are unavailable, finish useful authorized work, mark dependent verification blocked or unverified, and state the next concrete check. Never invent evidence or treat Markdown as tool-level enforcement.

## Quality checks

Exercise the main journey with keyboard and representative data. Inspect errors, slow responses, long content, contrast, zoom, and responsive behavior. Verify that actions persist and that protected information is not exposed through hidden UI.

## Deliverable

Working screens, visual direction/tokens, state coverage, viewport and interaction evidence, integration status and outstanding visual or accessibility gaps.

## Example

“Build a fee-entry page.” Include student selection, amount validation, submission progress, duplicate protection, a receipt result, and recoverable errors.

## Skill coordination

Use kad-requirements-analysis when journeys are unclear, kad-backend-api for contract changes, kad-security-engineering for protected flows, and kad-testing-quality for meaningful acceptance checks.

## Completion rule

Report completion only for acceptance criteria supported by evidence. Mark partial, blocked or unverified work explicitly. Explain material deviations and their effects; use expert judgment within the user’s scope and host rules. Reuse existing authorization; this skill grants no new permissions.
