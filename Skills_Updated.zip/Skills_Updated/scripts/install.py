"""Preview or install project instructions without overwriting existing files."""
import argparse
from pathlib import Path
import sys
from validate_pack import ROOT, validate

def install(target, apply=False):
    validate()
    raw = Path(target).expanduser().absolute()
    for ancestor in [raw, *raw.parents]:
        if ancestor.is_symlink():
            raise ValueError('Symlinked target paths are not supported')
        if ancestor.exists() and not ancestor.is_dir():
            raise ValueError('Target parent is not a directory')
    target = raw.resolve()
    if target == ROOT or target.is_relative_to(ROOT):
        raise ValueError('Choose a project outside the extracted package')
    sources = [ROOT / n for n in ('AGENTS.md', 'AGENT.md', 'SKILLS.md', 'skills-index.json')]
    sources += sorted(p for p in (ROOT / '.agents/skills').rglob('*') if p.is_file())
    pending, skipped = [], []
    for src in sources:
        dst = target / src.relative_to(ROOT)
        for node in [dst, *dst.parents]:
            if node == target.parent:
                break
            if node.is_symlink():
                raise ValueError('Symlink in destination: ' + str(node))
            if node != dst and node.exists() and not node.is_dir():
                raise ValueError('Destination parent is not a directory: ' + str(node))
        if dst.exists():
            if not dst.is_file() or dst.read_bytes() != src.read_bytes():
                raise ValueError('Existing file differs; merge manually: ' + str(dst))
            skipped.append(dst)
        else:
            pending.append((src, dst))
    created = []
    if apply:
        try:
            for src, dst in pending:
                dst.parent.mkdir(parents=True, exist_ok=True)
                with dst.open('xb') as out:
                    created.append(dst)
                    out.write(src.read_bytes())
        except Exception:
            for path in reversed(created):
                path.unlink()
            raise
    print(('Installed' if apply else 'Would install') + f' {len(pending)} files; {len(skipped)} identical files skipped.')
    print('Target: ' + str(target))
    if not apply:
        print('No changes made. Add --apply to install after reviewing the target.')
    return len(pending), len(skipped)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--target', required=True)
    parser.add_argument('--apply', action='store_true')
    args = parser.parse_args()
    try:
        install(args.target, args.apply)
    except (ValueError, OSError, KeyError) as exc:
        print('Install stopped: ' + str(exc), file=sys.stderr)
        sys.exit(1)
