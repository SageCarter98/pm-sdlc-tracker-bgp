---
name: kad-devops-delivery
description: "Use for build pipelines, containers, environment configuration, deployments, and release automation."
---

# DevOps and Delivery

## Purpose and inputs

Apply this workflow to the requested task without expanding its scope. Use build and runtime requirements, environments, deployment target, secrets mechanism, release authorization, and rollback constraints.

## Workflow

1. Inspect runtime versions, lockfiles, build commands, target environment, release scope and existing authorization.
2. Separate reproducible build, tests, immutable artifact preparation and deployment steps; use supported secrets handling and least-privilege identities.
3. Validate pipeline/configuration and required preflight checks; sequence database changes with compatible application releases.
4. Prepare rollback or roll-forward steps proportionate to risk and identify irreversible side effects.
5. For authorized deployment, release the intended artifact, inspect health, exercise a meaningful smoke journey and monitor failure signals.
6. Report configuration validation, deployment execution and live success separately; preserve recovery evidence on failure.

## Decision rules and boundaries

Do not deploy merely because a pipeline file exists or the skill is approved. Honor authorization already provided for the actual target. Avoid mutable production artifacts, hard-coded secrets, and unbounded automated retries. Document when a database change makes binary rollback insufficient.

## Tools and evidence

Select and read this skill before specialist execution; apply its relevant steps rather than merely naming it. Inspect actual project commands and installed versions before choosing tools. Use official references for uncertain or version-sensitive technical claims. Load only supporting skills justified by the task; reselect when scope crosses a new boundary.

For substantial work, tie acceptance criteria to changed artifacts and actual check results. Distinguish selected, loaded, applied and verified: reading proves only loading. Keep a brief record of applied skills, meaningful commands/results, limitations and justified deviations; a concise final summary suffices for a small task. Do not run ritual tests or weaken required checks to claim success. If tools or access are unavailable, finish useful authorized work, mark dependent verification blocked or unverified, and state the next concrete check. Never invent evidence or treat Markdown as tool-level enforcement.

## Quality checks

Run build and pipeline checks available locally. Validate configuration against the target tooling. For authorized deployment, verify health and a meaningful smoke journey; state clearly when only the configuration was tested.

## Deliverable

Pipeline/artifact/environment evidence, actual release status, smoke results and recovery procedure.

## Example

“Deploy the new API.” Verify the intended environment and authorization, complete preflight checks, deploy, exercise health and a core operation, and monitor failure signals.

## Skill coordination

Use kad-database-engineering for migrations, kad-infrastructure-networks for connectivity, and kad-performance-reliability for rollout signals.

## Completion rule

Report completion only for acceptance criteria supported by evidence. Mark partial, blocked or unverified work explicitly. Explain material deviations and their effects; use expert judgment within the user’s scope and host rules. Reuse existing authorization; this skill grants no new permissions.
