---
name: kad-performance-reliability
description: "Use for measured latency or resource problems, capacity planning, reliability targets, incident response, and recovery design."
---

# Performance and Reliability

## Purpose and inputs

Apply this workflow to the requested task without expanding its scope. Use representative workload, baseline measurements, service objectives, telemetry, dependency behavior, and incident scope.

## Workflow

1. Define the user-visible symptom, authorized workload and measurable target; label proposed targets as proposals.
2. Measure latency distribution, throughput, errors and saturation under representative conditions.
3. Locate the dominant cost with profiling or tracing, distinguishing database, network, server and rendering work.
4. Change the evidenced cause and compare equivalent workloads; check correctness and resource trade-offs.
5. For incidents, prioritise safe containment and restoration, preserve evidence and then investigate causes.
6. Exercise relevant timeout, overload, dependency-loss or recovery behaviour within authorized limits; report residual risk.

## Decision rules and boundaries

Do not optimize from intuition alone or present a microbenchmark as end-to-end proof. Bound queues and retries; account for retry amplification and cache invalidation. Distinguish restoration targets from measured recovery ability. Capacity tests must stay within authorized environments and load limits.

## Tools and evidence

Select and read this skill before specialist execution; apply its relevant steps rather than merely naming it. Inspect actual project commands and installed versions before choosing tools. Use official references for uncertain or version-sensitive technical claims. Load only supporting skills justified by the task; reselect when scope crosses a new boundary.

For substantial work, tie acceptance criteria to changed artifacts and actual check results. Distinguish selected, loaded, applied and verified: reading proves only loading. Keep a brief record of applied skills, meaningful commands/results, limitations and justified deviations; a concise final summary suffices for a small task. Do not run ritual tests or weaken required checks to claim success. If tools or access are unavailable, finish useful authorized work, mark dependent verification blocked or unverified, and state the next concrete check. Never invent evidence or treat Markdown as tool-level enforcement.

## Quality checks

Check tail latency and failure behavior as well as averages. Verify correctness after optimization. Exercise timeout, overload, dependency loss, and recovery scenarios relevant to the change.

## Deliverable

Comparable before/after measurements or incident timeline, workload details, correctness checks and measured versus planned recovery ability.

## Example

“Reports are slow.” Measure query time, transfer, server processing, and rendering; fix the dominant cost and report the same workload before and after.

## Skill coordination

Use the affected implementation skill for changes, kad-devops-delivery for rollout and kad-database-engineering for query evidence.

## Completion rule

Report completion only for acceptance criteria supported by evidence. Mark partial, blocked or unverified work explicitly. Explain material deviations and their effects; use expert judgment within the user’s scope and host rules. Reuse existing authorization; this skill grants no new permissions.
