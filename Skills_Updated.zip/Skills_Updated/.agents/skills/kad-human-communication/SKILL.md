---
name: kad-human-communication
description: "Use when explaining engineering decisions, writing user-facing messages, teaching a technical concept, or revising text for natural language."
---

# Human Communication

## Purpose and inputs

Apply this workflow to the requested task without expanding its scope. Use audience, purpose, user vocabulary, requested format, and the actual technical evidence.

## Workflow

1. Identify the reader, purpose, requested format and verified facts.
2. Lead with the useful outcome or next action; explain cause and consequence in familiar words.
3. Use connected paragraphs for explanation and concise lists for genuine steps or comparisons; define necessary terms once.
4. For product messages, say what happened, what is known about saved work and what the user can do; keep stack traces in diagnostics.
5. Check names, numbers, uncertainty and technical meaning survived simplification; remove repetition, jargon and forced praise.
6. Deliver ready-to-use text, preserving honest limitations and avoiding fabricated personal experience.

## Decision rules and boundaries

Sound warm and direct without forced praise, artificial enthusiasm, canned transitions, or invented personal stories. Do not imitate errors to sound human. Do not hide material uncertainty, security limitations, authorship, or failed checks. Keep implementation details out of product messages unless the user needs them to act.

## Tools and evidence

Select and read this skill before specialist execution; apply its relevant steps rather than merely naming it. Inspect actual project commands and installed versions before choosing tools. Use official references for uncertain or version-sensitive technical claims. Load only supporting skills justified by the task; reselect when scope crosses a new boundary.

For substantial work, tie acceptance criteria to changed artifacts and actual check results. Distinguish selected, loaded, applied and verified: reading proves only loading. Keep a brief record of applied skills, meaningful commands/results, limitations and justified deviations; a concise final summary suffices for a small task. Do not run ritual tests or weaken required checks to claim success. If tools or access are unavailable, finish useful authorized work, mark dependent verification blocked or unverified, and state the next concrete check. Never invent evidence or treat Markdown as tool-level enforcement.

## Quality checks

Read the text aloud mentally: remove repetition and inflated phrasing. Confirm that the first paragraph answers the request and that every confident claim has support. Check that simplified language preserves technical accuracy.

## Deliverable

Audience-appropriate wording with accurate claims, useful actions and no unnecessary internal details.

## Example

“Explain why login failed to a school clerk.” Say what happened, whether their work is saved if known, and the next action; keep stack traces in technical logs.

## Skill coordination

Use kad-documentation-handover for maintained guides and the relevant domain skill when technical facts require checking. Do not load specialist implementation skills for a simple rewrite with complete facts.

## Completion rule

Report completion only for acceptance criteria supported by evidence. Mark partial, blocked or unverified work explicitly. Explain material deviations and their effects; use expert judgment within the user’s scope and host rules. Reuse existing authorization; this skill grants no new permissions.
