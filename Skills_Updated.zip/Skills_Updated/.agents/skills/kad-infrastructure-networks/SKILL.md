---
name: kad-infrastructure-networks
description: "Use for server administration, network diagnosis, DNS, TLS, firewall rules, and infrastructure configuration."
---

# Infrastructure and Networks

## Purpose and inputs

Apply this workflow to the requested task without expanding its scope. Use authorized hosts, topology, services and ports, relevant configuration, access constraints, and current symptoms.

## Workflow

1. Confirm authorized hosts, symptoms, topology, management access and recovery channel.
2. Trace DNS, routing, transport, TLS, proxy and application boundaries using minimally disruptive diagnostics.
3. Compare intended configuration with observed service state and isolate the failing layer.
4. Prepare narrow repeatable changes, validate syntax and preserve a route back before any authorized disruption.
5. Verify both intended connectivity and denied paths, certificate behaviour and service health.
6. Record diagnosis, changed configuration, actual checks and recovery limitations.

## Decision rules and boundaries

Do not scan unrelated targets or disable TLS and firewalls as a lasting fix. Preserve a recovery channel before changing remote access. Redact credentials and sensitive infrastructure details from shared reports. Prefer validated configuration changes over manual drift.

## Tools and evidence

Select and read this skill before specialist execution; apply its relevant steps rather than merely naming it. Inspect actual project commands and installed versions before choosing tools. Use official references for uncertain or version-sensitive technical claims. Load only supporting skills justified by the task; reselect when scope crosses a new boundary.

For substantial work, tie acceptance criteria to changed artifacts and actual check results. Distinguish selected, loaded, applied and verified: reading proves only loading. Keep a brief record of applied skills, meaningful commands/results, limitations and justified deviations; a concise final summary suffices for a small task. Do not run ritual tests or weaken required checks to claim success. If tools or access are unavailable, finish useful authorized work, mark dependent verification blocked or unverified, and state the next concrete check. Never invent evidence or treat Markdown as tool-level enforcement.

## Quality checks

Check configuration syntax, intended connectivity, denied paths, certificate validity, and service health. Verify a route back to the prior configuration before disruptive authorized changes.

## Deliverable

Layer-specific diagnosis, scoped configuration change, connectivity/denial results and safe recovery steps.

## Example

“The application is unreachable.” Distinguish DNS failure, refused connection, timeout, TLS failure, proxy error, and application error before changing configuration.

## Skill coordination

Use kad-debugging for application faults, kad-security-engineering for access changes and kad-devops-delivery for deployment configuration.

## Completion rule

Report completion only for acceptance criteria supported by evidence. Mark partial, blocked or unverified work explicitly. Explain material deviations and their effects; use expert judgment within the user’s scope and host rules. Reuse existing authorization; this skill grants no new permissions.
