---
name: kad-testing-quality
description: "Use to design meaningful test coverage, verify behavior changes, and assess acceptance evidence."
---

# Testing and Quality

## Purpose and inputs

Apply this workflow to the requested task without expanding its scope. Use requirements and risk, changed behavior, existing tests, dependencies, and available environments.

## Workflow

1. Inspect acceptance criteria, changed behaviour, existing tests and available environments; rank risk before selecting checks.
2. Map meaningful criteria to unit tests for rules, integration tests for boundaries/persistence and a small number of essential end-to-end journeys.
3. Include negative authorization, failure, concurrency and recovery cases only where they affect the change; isolate state and use deterministic fixtures.
4. For frontend work, assess rendered appearance separately from build success and exercise actual interactions; use kad-frontend-engineering for the visual review.
5. Run focused checks and required project gates. Confirm a regression test detects the original defect when feasible; distinguish an environment failure from a product defect.
6. Record commands, environment, outcomes and untested criteria. Stop optional testing when remaining risk is resolved; never remove meaningful assertions to get green output.

## Decision rules and boundaries

Do not equate coverage percentage with correctness. Avoid tests that merely restate implementation or snapshot irrelevant formatting. Distinguish product failure from a broken test environment. Never remove a failing assertion merely to get green output.

## Tools and evidence

Select and read this skill before specialist execution; apply its relevant steps rather than merely naming it. Inspect actual project commands and installed versions before choosing tools. Use official references for uncertain or version-sensitive technical claims. Load only supporting skills justified by the task; reselect when scope crosses a new boundary.

For substantial work, tie acceptance criteria to changed artifacts and actual check results. Distinguish selected, loaded, applied and verified: reading proves only loading. Keep a brief record of applied skills, meaningful commands/results, limitations and justified deviations; a concise final summary suffices for a small task. Do not run ritual tests or weaken required checks to claim success. If tools or access are unavailable, finish useful authorized work, mark dependent verification blocked or unverified, and state the next concrete check. Never invent evidence or treat Markdown as tool-level enforcement.

## Quality checks

Run the focused suite and required repository gates. Capture commands, environment, result, and untested areas. Check that a regression test fails for the original defect when feasible.

## Deliverable

Test cases or code, actual execution results, and a clear acceptance assessment.

## Example

“The payment fix passes one test.” Add relevant duplicate, concurrent, invalid amount, permission, and persistence checks before judging the invariant.

## Skill coordination

Load the affected domain skill for its acceptance obligations and kad-debugging when failures need investigation. Use kad-data-ai-engineering for held-out model/agent evaluations.

## Completion rule

Map each critical criterion to actual evidence. Report partial, blocked or unverified checks accurately. Apply this skill rather than merely naming it; explain material deviations and reuse existing authorization without granting new permissions.
