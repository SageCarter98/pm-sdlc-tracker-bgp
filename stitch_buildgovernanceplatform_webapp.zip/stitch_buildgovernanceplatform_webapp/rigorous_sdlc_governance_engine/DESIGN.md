---
name: Rigorous SDLC Governance Engine
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#45464d'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#76777d'
  outline-variant: '#c6c6cd'
  surface-tint: '#565e74'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#131b2e'
  on-primary-container: '#7c839b'
  inverse-primary: '#bec6e0'
  secondary: '#545f73'
  on-secondary: '#ffffff'
  secondary-container: '#d5e0f8'
  on-secondary-container: '#586377'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#00174b'
  on-tertiary-container: '#497cff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dae2fd'
  primary-fixed-dim: '#bec6e0'
  on-primary-fixed: '#131b2e'
  on-primary-fixed-variant: '#3f465c'
  secondary-fixed: '#d8e3fb'
  secondary-fixed-dim: '#bcc7de'
  on-secondary-fixed: '#111c2d'
  on-secondary-fixed-variant: '#3c475a'
  tertiary-fixed: '#dbe1ff'
  tertiary-fixed-dim: '#b4c5ff'
  on-tertiary-fixed: '#00174b'
  on-tertiary-fixed-variant: '#003ea8'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Inter
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: 0em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.04em
  code-md:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: 0em
  code-sm:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-compact: 0.5rem
  margin: 1.5rem
  margin-mobile: 1rem
  space-2xs: 0.125rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
  space-2xl: 2rem
---

## Brand & Style

The platform embodies the authoritative, uncompromising standard of mission-critical software delivery and institutional release compliance. Built for enterprise release managers, compliance auditors, and engineering leadership, the interface communicates zero-tolerance integrity, legal defensibility, and absolute operational certainty.

The aesthetic fuses **Corporate High-Density Systematics** with **Precision Engineering Minimalism**. It avoids decorative ephemera, frivolous animations, and soft organic abstractions. Instead, the design system relies on architectural planar surfaces, precise tabular alignments, clear structural grid divisions, and explicit status signaling. Every UI element exists to verify state, prevent human error during approval gates, and maintain an indisputable audit trail.

Key Tenets:
- **Immutable Defensibility:** Visual language mirrors official registers, formal documentation, and cryptographic ledgers.
- **Unambiguous State Signaling:** System statuses (saved, draft, approved, conditional, blocked) leave zero room for interpretive ambiguity.
- **Cognitive Ergonomics Under Density:** Complex workflows containing hundreds of audit criteria remain readable via strict hierarchy, deliberate typography scales, and modular structural boundaries.

## Colors

The color system enforces a rigorous semantic taxonomy designed to satisfy WCAG 2.2 AA contrast requirements (minimum 4.5:1 for body text, 3:1 for graphical interfaces and state indicators) across all surface pairings.

### Core Architectural Surfaces
- **Canvas Base:** `#F8FAFC` (Slate 50) creates a grounded, non-reflective base plane that reduces optical fatigue during prolonged audit sessions.
- **Card / Surface Container:** `#FFFFFF` provides stark, high-contrast working planes for actionable and readable content.
- **Structural Borders & Separators:** `#E2E8F0` (Slate 200) renders crisp 1px delineation lines without adding visual visual clutter.
- **Surface Hover & Subtle Tiers:** `#F1F5F9` (Slate 100).

### Institutional Primaries
- **Brand Authority Primary:** `#0F172A` (Slate 900) anchors high-order headers, key navigation structures, and high-impact structural framing.
- **Structural Secondary:** `#1E293B` (Slate 800) drives sub-headers, interactive tab containers, and baseline controls.

### Governance State System (Explicit Pairings)
Every governance state indicator requires a background, border, and text token pairing to preserve compliance across states:
- **Approved / Recorded / Compliant:**
  - Background: `#ECFDF5` (Emerald 50)
  - Border: `#A7F3D0` (Emerald 200)
  - Text / Icon: `#059669` (Emerald 600) / Deep variant: `#065F46` (Emerald 800)
- **Conditional / Warning / Review Required:**
  - Background: `#FFFBEB` (Amber 50)
  - Border: `#FDE68A` (Amber 200)
  - Text / Icon: `#D97706` (Amber 600) / Deep variant: `#92400E` (Amber 800)
- **Blocker / Hold / Non-Compliant / Termination:**
  - Background: `#FEF2F2` (Rose/Crimson 50)
  - Border: `#FECACA` (Rose/Crimson 200)
  - Text / Icon: `#DC2626` (Crimson 600) / Deep variant: `#991B1B` (Crimson 800)
- **Pending / Draft / Staged:**
  - Background: `#F1F5F9` (Slate 100)
  - Border: `#CBD5E1` (Slate 300)
  - Text / Icon: `#475569` (Slate 600) / Deep variant: `#1E293B` (Slate 800)
- **Info / Actionable Link / Audit Telemetry:**
  - Background: `#EFF6FF` (Blue 50)
  - Border: `#BFDBFE` (Blue 200)
  - Text / Icon: `#2563EB` (Cobalt 600) / Deep variant: `#1E40AF` (Cobalt 800)

## Typography

The platform utilizes **Inter** for UI narrative, layout headings, and data reading, paired with **JetBrains Mono** for machine-parsable metadata, cryptographic digests, and deterministic system references.

### OpenType & Tabular Figures
To guarantee vertical alignment in dense tables and ledger columns, all tabular numbers inside Inter must implement `font-feature-settings: "tnum" 1, "cv05" 1, "cv11" 1` (tabular numerals, lowercase l with tail, single-story a). This prevents horizontal jitter when values mutate in real time.

### Monospace Identifier Guidelines
`JetBrains Mono` is strictly applied to:
- Git/Commit SHA hashes (e.g., `8f9b2a1c`)
- Governance release artifact versions (e.g., `v1.24.0-rc.3`)
- Governance tracking codes (e.g., `FE-APR-001`, `CR-8890-POL`)
- RFC 3339 UTC timestamps (e.g., `2024-10-24 14:02:11Z`)
- Cryptographic verification signatures and checksums.

## Layout & Spacing

The layout model is anchored on an **8pt base grid with a 4pt micro-step system**, optimized for dense operational cockpits. 

### Grid & Responsiveness
- **Desktop (1440px and above):** 12-column responsive fluid grid with fixed maximum width container (`1600px`). Gutters remain fixed at `1rem` (16px) to maximize horizontal data display for multi-column SDLC matrices.
- **Medium / Tablet (768px – 1439px):** 8-column layout with `1rem` gutters. Toolbars and multi-action headers wrap into dual-tier control bars.
- **Mobile (< 768px):** 4-column layout with `0.5rem` gutters. Tables reflow into stacked, verified manifest cards; table side-scroll is only permitted on immutable diff-views.

### Spacing Philosophy
Spacing tokens govern empty space and component breathing room. High data density must never sacrifice visual separation; rather than generous blank areas, clear boundaries are sustained by rigid alignment and consistent padding intervals (`space-sm` for compact cell rows, `space-md` for standard card bodies).

## Elevation & Depth

To reflect institutional rigor and prevent distraction, depth is conveyed through **tonal surface stacking** and **crisp 1px structural outlines** rather than diffuse decorative drop shadows.

- **Level 0 (Base Canvas):** `#F8FAFC`. Used strictly for the non-interactive viewport environment.
- **Level 1 (Structural Containers & Cards):** `#FFFFFF` framed by a 1px solid border in `#E2E8F0`. No shadow.
- **Level 2 (Dropdowns, Menus, Flyouts):** `#FFFFFF` framed by a 1px solid border in `#CBD5E1` with an ambient precision shadow: `0 4px 6px -1px rgba(15, 23, 42, 0.08), 0 2px 4px -2px rgba(15, 23, 42, 0.04)`.
- **Level 3 (Modal Overlays & Gate Sign-off Drawers):** `#FFFFFF` paired with an administrative backdrop shield (`rgba(15, 23, 42, 0.60)` with `backdrop-filter: blur(2px)`). Modals carry an outer keyline border of `#94A3B8` and deep elevation: `0 20px 25px -5px rgba(15, 23, 42, 0.15), 0 8px 10px -6px rgba(15, 23, 42, 0.1)`.

### Border Integrity
Every card, cell division, panel, and table header maintains unambiguous 1px rectilinear perimeter separation (`#E2E8F0`). Borders do not soften on hover; state changes are communicated via background fill shifts (`#F8FAFC` to `#F1F5F9`) or accent border indicators.

## Shapes

The interface embraces a **disciplined, semi-sharp geometry** (`roundedness: 1`):
- **Base Components (Buttons, Inputs, Table Cells, Checkboxes):** `0.25rem` (4px). Provides enough softness to avoid brittle brutalism while projecting industrial precision.
- **Panels, Flyouts, Containers, Modal Frames (`rounded-lg`):** `0.5rem` (8px). Keeps high-density window boundaries sharp and contained.
- **Pills & Indicator Badges:** Small contextual status tokens may adopt full pill shapes (`9999px`) only when indicating binary recording states (e.g., `Saved`, `Recorded`) to immediately distinguish ephemeral status tags from interactive buttons.

## Components

### 1. High-Density Data Tables
- **Header Structure:** 36px height, background `#F8FAFC`, border-bottom `1px solid #CBD5E1`. Typography is `label-sm`, uppercase, tracked (`letterSpacing: 0.04em`), color `#475569`.
- **Row Specs:** 40px default row height (dense mode 32px), border-bottom `1px solid #E2E8F0`. Alternating row zebra fills are rejected in favor of high-contrast hover fill: `#F8FAFC`.
- **Data Alignment:** Numeric, version, and hash columns align strictly right using tabular figures. Text, tags, and actor IDs align left.
- **Frozen Action Column:** The terminal right column (containing audit links, override triggers) is permanently anchored with an internal border-left `1px solid #E2E8F0`.

### 2. Status Indicators & Pills
Statuses must never rely solely on color; they must combine color, an unmistakable label, and an explicit icon.
- **Persistence Indicator (Live State):**
  - *Saving:* Slate dot with pulsing animation + `label-sm` "Saving..."
  - *Saved:* Emerald solid dot (`#059669`) + `label-sm` "Changes Saved"
  - *Not Saved / Dirty:* Amber outlined warning ring (`#D97706`) + `label-sm` "Unsaved Modifications"
- **Audit Gate Pills:** 
  - Height 22px, padding `0 8px`, border radius `9999px`, font `code-sm`.
  - *Approved/Recorded:* Fill `#ECFDF5`, Border `#A7F3D0`, Text `#065F46`, Icon `check-circle`.
  - *Conditional:* Fill `#FFFBEB`, Border `#FDE68A`, Text `#92400E`, Icon `alert-triangle`.
  - *Blocker/Hold:* Fill `#FEF2F2`, Border `#FECACA`, Text `#991B1B`, Icon `shield-alert`.
  - *Pending:* Fill `#F1F5F9`, Border `#CBD5E1`, Text `#334155`, Icon `clock`.

### 3. Separation-of-Duty (SoD) Badges & Callouts
- Used when an action requires distinct author-checker roles or multi-party authorization.
- Structural box with `0.25rem` radius, border-left `4px solid #0F172A`, background `#F8FAFC`, border `1px solid #E2E8F0` (top, right, bottom).
- Contains actor provenance slot: "Staged by: [Actor A]" and "Sign-off required: [Qualified Role B, excluded: Actor A]".

### 4. Blocker & Compliance Callout Banners
- Full-width panel with 1px border.
- Critical Blocker: `#FEF2F2` background, `#DC2626` solid 1px border, `#991B1B` header text.
- Must display three explicit slots:
  1. *Rule Violation ID* (e.g., `POL-SDLC-SEC-09`) in `code-sm`.
  2. *Blocking Root Cause Description* in `body-md`.
  3. *Remediation Pathway / Designated Authority* in `body-sm`.

### 5. Progressive Disclosure Accordions
- Bound by standard container borders (`#E2E8F0`).
- Header trigger maintains persistent `12px` padding, displaying collapse chevron left-aligned with title text, followed by metadata pills and dynamic rule status right-aligned.
- Expansion state must not reflow content vertically with slow easing; transition is instantaneous (`duration: 100ms ease-out`) to prioritize operator velocity.

### 6. Immutable Manifest Summaries
- Read-only review blocks resembling signed legal receipts.
- Background `#F8FAFC`, dotted interior line separators (`#CBD5E1`), displaying commit hash, pipeline run ID, verified dependencies count, and cryptographic signature in `code-md`.
- Action includes a one-click "Copy Immutable Manifest JSON" with visual verification feedback.

### 7. Form Inputs & Interactive Controls
- **Inputs:** Height 36px, border `1px solid #CBD5E1`, background `#FFFFFF`, text `body-md`.
- **Buttons:** 
  - *Primary:* `#0F172A` fill, `#FFFFFF` text, hover `#1E293B`.
  - *Destructive / Terminate:* `#DC2626` fill, `#FFFFFF` text, hover `#B91C1C`.
  - *Secondary / Bordered:* `#FFFFFF` fill, `1px solid #CBD5E1`, `#1E293B` text, hover `#F8FAFC`.
- **Checkboxes & Radios:** Sharp `0.25rem` corners for checkboxes; circular for radios. Inactive border `1.5px solid #64748B`. Active state `#0F172A` fill with white indicator.

### 8. Rigorous Accessible Focus States (WCAG 2.2 AA Compliant)
- Default operating system focus rings are disabled across all custom components.
- Standard focus state: An unambiguous `2px` solid outline in `#2563EB` (Cobalt 600) with a `2px` offset (`outline-offset: 2px`).
- Dark-surface focus state: `2px` solid `#60A5FA` with `2px` offset.
- Ensures a minimum 3:1 contrast ratio against both component perimeter and surrounding canvas.