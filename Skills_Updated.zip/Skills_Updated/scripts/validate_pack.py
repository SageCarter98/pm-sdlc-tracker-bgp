"""Validate this reviewed package; standard library only."""
import hashlib
import json
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]

def validate(root=ROOT):
    root = Path(root).resolve()
    index = json.loads((root / 'skills-index.json').read_text(encoding='utf-8'))
    names = set()
    if len(index['skills']) != 20:
        raise ValueError('Expected 20 skills')
    for item in index['skills']:
        name = item['name']
        if not re.fullmatch(r'kad-[a-z0-9-]+', name) or name in names:
            raise ValueError('Invalid or duplicate skill name')
        names.add(name)
        expected = f'.agents/skills/{name}/SKILL.md'
        if item['path'] != expected:
            raise ValueError('Unexpected skill path')
        path = root / expected
        if path.is_symlink() or not path.resolve().is_relative_to(root):
            raise ValueError('Skill path escapes package')
        text = path.read_text(encoding='utf-8')
        if not text.startswith(f'---\nname: {name}\ndescription: '):
            raise ValueError('Invalid frontmatter: ' + name)
        front = text.split('---', 2)[1].splitlines()
        desc = next(line.removeprefix('description: ') for line in front if line.startswith('description: '))
        if json.loads(desc) != item['description']:
            raise ValueError('Catalogue description mismatch: ' + name)
        for heading in ('Purpose and inputs', 'Workflow', 'Decision rules and boundaries', 'Tools and evidence', 'Quality checks', 'Deliverable', 'Example', 'Skill coordination', 'Completion rule'):
            if f'## {heading}' not in text:
                raise ValueError('Incomplete skill: ' + name)
        if 'TODO' in text:
            raise ValueError('Unfinished skill: ' + name)
    if not (root / '.agents/skills/kad-frontend-engineering/references/visual-quality.md').is_file():
        raise ValueError('Missing frontend visual reference')
    if (root / 'AGENT.md').read_bytes() != (root / 'AGENTS.md').read_bytes():
        raise ValueError('Agent entrypoints differ')
    manifest = json.loads((root / 'SHA256SUMS.json').read_text(encoding='utf-8'))
    actual = set()
    for p in root.rglob('*'):
        if '__pycache__' in p.parts:
            continue
        if p.is_symlink():
            raise ValueError('Symlink in package: ' + str(p))
        if p.is_file() and p.name != 'SHA256SUMS.json':
            rel = p.relative_to(root).as_posix()
            actual.add(rel)
            digest = hashlib.sha256(p.read_bytes()).hexdigest()
            if manifest.get(rel) != digest:
                raise ValueError('Missing or changed checksum: ' + rel)
    if actual != set(manifest):
        raise ValueError('Manifest contains missing files')
    return {'skills': len(names), 'files_verified': len(actual), 'status': 'passed'}

if __name__ == '__main__':
    try:
        print(json.dumps(validate(), indent=2))
    except (ValueError, OSError, KeyError, StopIteration) as exc:
        print('Validation failed: ' + str(exc), file=sys.stderr)
        sys.exit(1)
